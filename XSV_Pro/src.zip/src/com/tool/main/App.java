package com.tool.main;

import com.tool.view.HomePage;

public class App {

	public static void main(String args[]){
		HomePage homepage=new HomePage();
		homepage.initialize();
	}
	
}
