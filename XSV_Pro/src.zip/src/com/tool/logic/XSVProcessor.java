package com.tool.logic;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Generated;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;

import com.tool.view.HomePage;

public class XSVProcessor extends SwingWorker<List<File>, String> {

	FileReader fileReader;
	BufferedReader reader;
	String tempString;

	long timestamp;
	FileWriter writer;
	List<File> returnFiles;
	String outputPath;

	// public List<File> splitXSV(File[] filesInFolder, String delimiter,
	// String split, String Keyword, boolean isExactValue) {
	public List<File> doInBackground() throws Exception {

		File[] filesInFolder = HomePage.filesInFolder;
		String delimiter = HomePage.delimiterText.getText();
		String maxsizeperfile = HomePage.countText.getText();
		String Keyword = HomePage.keyWordText.getText();
		boolean isExactValue = HomePage.exactCheckbox.isSelected();

		String[] arrayContainingKeywords=null;
		File fileContainingKeyword = HomePage.fileContainingKeywords;
		boolean keywordinfile = false;
		if (fileContainingKeyword != null) {
			keywordinfile = true;
			fileReader = new FileReader(fileContainingKeyword);
			reader = new BufferedReader(fileReader);
			while ((tempString = reader.readLine()) != null) {
				arrayContainingKeywords = tempString.split(",", -1);
			}

		}
		returnFiles = new ArrayList<File>();
		int splitsize = 50000;

		if (!maxsizeperfile.equalsIgnoreCase("") && maxsizeperfile != null) {
			splitsize = Integer.parseInt(maxsizeperfile);
		}

		int recordCount = 1;
		List<String> outputRecords = new ArrayList<String>();
		timestamp = new Date().getTime();
		int filecount = 1;

		for (int filesIterator = 0; filesIterator < filesInFolder.length; filesIterator++) {
			System.out.println("Processing file.."
					+ filesInFolder[filesIterator].getName());
			publish("Processing file.."
					+ filesInFolder[filesIterator].getName() + "\n");
			try {
				fileReader = new FileReader(filesInFolder[filesIterator]);
				reader = new BufferedReader(fileReader);
				while ((tempString = reader.readLine()) != null) {
					// System.out.println("Record count.."+recordCount);
					if ((recordCount > splitsize) && (splitsize != 0)) {
						publish("Writing outputfile no "+filecount);
						writeToFile(outputRecords, filecount);
						recordCount = 0;
						filecount++;
						outputRecords = new ArrayList<String>();
					}
					if (!delimiter.equalsIgnoreCase("") && delimiter != null) {
						String[] valuesInThisRecord = tempString
								.split(delimiter);

						if ((Keyword.equalsIgnoreCase("") || Keyword == null)&&(!keywordinfile)) {
							outputRecords.add(tempString);
							recordCount++;
						} else {
							if (doesRecordContain(valuesInThisRecord, Keyword,
									isExactValue, arrayContainingKeywords,
									keywordinfile)) {
								outputRecords.add(tempString);
								recordCount++;
								break;
							}
						}
					} else {
						outputRecords.add(tempString);
						recordCount++;
					}
				}
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (recordCount > 0) {
			try {
				writeToFile(outputRecords, filecount);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return returnFiles;
	}

	public void writeToFile(List<String> records, int fileCount)
			throws IOException {
		File file = new File("D:/saravanan/XSVProFiles/OuputFile_" + timestamp
				+ "_" + fileCount + ".xsv");

		if (!file.getParentFile().exists()) {
			file.getParentFile().mkdirs();
		}
		outputPath = file.getParentFile().getPath();
		writer = new FileWriter(file, true);
		for (String record : records) {
			writer.write(record + "\n");
		}
		writer.close();
		returnFiles.add(file);
	}

	public boolean doesRecordContain(String[] valuesInRecord, String keyword,
			boolean isExact, String[] manyKeywords, boolean isKeywordFile) {

		if (!isKeywordFile) {
			for (int i = 0; i < valuesInRecord.length; i++) {
				if (isExact) {
					if (valuesInRecord[i].equals(keyword)) {
						return true;
					}
				} else {
					if (valuesInRecord[i].contains(keyword)) {
						return true;
					}
				}
			}
			return false;
		} else {

			for (int i = 0; i < valuesInRecord.length; i++) {
				if (isExact) {
					for (int keyworditerator = 0; keyworditerator < manyKeywords.length; keyworditerator++) {
						if (valuesInRecord[i]
								.equals(manyKeywords[keyworditerator])) {
							return true;
						}
					}
				} else {
					for (int keyworditerator = 0; keyworditerator < manyKeywords.length; keyworditerator++) {
						if (valuesInRecord[i]
								.contains(manyKeywords[keyworditerator])) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	protected void process(java.util.List<String> messages) {
		for (String message : messages) {
			HomePage.UserMessage.setForeground(Color.blue);
			HomePage.UserMessage.setText(message);
			HomePage.textArea.setForeground(Color.blue);
			String text = HomePage.textArea.getText();
			HomePage.textArea.setText(text + message);
		}
	}

	@Override
	protected void done() {
		JOptionPane.showMessageDialog(null,
				"Operation completed! ouputfiles generated!");
		HomePage.UserMessage.setForeground(Color.green);
		HomePage.UserMessage.setText("ouputfiles Generated @ " + outputPath);
	}
	// @Override
	// protected List<String> doInBackground() throws Exception {
	// // TODO Auto-generated method stub
	// return null;
	// }

}
