
package com.staples.pim.delegate.copyandprint.processor;

public class StepOutboundValidator {

}
