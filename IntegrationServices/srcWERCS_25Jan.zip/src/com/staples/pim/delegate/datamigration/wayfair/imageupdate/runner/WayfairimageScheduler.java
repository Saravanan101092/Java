
package com.staples.pim.delegate.datamigration.wayfair.imageupdate.runner;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.datamigration.wayfair.imageupdate.WayfairimageInboundProcessor;
import com.staples.pim.delegate.datamigration.wayfair.priceupdate.WayFairPriceInboundProcessor;
import com.staples.pim.delegate.datamigration.wayfair.priceupdate.runner.WayFairPriceScheduler;

import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.WAYFAIRIMAGE_INPUT_FOLDER;
import static com.staples.pim.base.util.IntgSrvAppConstants.FREEFORM_TRACE_LOGGER;

public class WayfairimageScheduler extends RunScheduler {

	IntgSrvLogger			logger		= IntgSrvLogger.getInstance(FREEFORM_TRACE_LOGGER);
	public static String	PUBLISH_ID	= "TLDE004";
	public static String	XSV			= ".dsv";

	/**	
	 * 
	 */
	public void run() {

		DatamigrationCommonUtil.printConsole("wayfairimageupdate scheduler invoked");
		logger.info("wayfairimage scheduler invoked");
		String inputFolder = IntgSrvUtils.reformatFilePath(IntgSrvPropertiesReader.getProperty(WAYFAIRIMAGE_INPUT_FOLDER));
		DatamigrationCommonUtil.printConsole("inputFolder : " + inputFolder);
		File folder = new File(inputFolder);
		File[] sortedFiles = DatamigrationCommonUtil.sortFilesBasedOnFIFO(folder, WayfairimageScheduler.PUBLISH_ID);

		List<File> fileList = new ArrayList<File>();
		fileList = Arrays.asList(sortedFiles);

		for (File inputfile : fileList) {
			if (inputfile.getName().endsWith(XSV)) {
				DatamigrationCommonUtil.printConsole(inputfile.getName());
				logger.info("File being processed : " + inputfile.getName());

				try {
					WayfairimageInboundProcessor.wayfairimageupdateProcessor(inputfile);
				} catch (Exception e) {
					logger.error(e);
					e.printStackTrace();
					IntgSrvUtils.alertByEmail(e, clazzname, WayfairimageScheduler.PUBLISH_ID);
				}
			} else {
				DatamigrationCommonUtil.printConsole("Invalid file format");
			}
			DatamigrationCommonUtil.moveFileToFileBad(inputfile, WayfairimageScheduler.PUBLISH_ID);
			logger.info("Bad file. Moved to File_Bad folder");
		}
	}

	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}
}
