package com.staples.pim.delegate.boomerang.writer;

public class MultiOutputItemWriterBoomerangCSV {

}
