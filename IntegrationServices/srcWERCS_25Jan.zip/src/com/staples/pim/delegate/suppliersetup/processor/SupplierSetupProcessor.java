
package com.staples.pim.delegate.suppliersetup.processor;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.base.util.IntgSrvAppConstants;
import com.staples.pim.base.util.IntgSrvUtils;

public class SupplierSetupProcessor {

	private IntgSrvLogger	traceLogger		= IntgSrvLogger.getInstance(IntgSrvAppConstants.FREEFORM_TRACE_LOGGER);
	private String			clazzname		= this.getClass().getName();

	private static String	supplierFolder	= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_FOLDER);
	private static String	supplierGroup	= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_GROUP);
	private static String	supplierUser	= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_USER);
	private static String	inboundFolder	= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_SETUP_INBOUND);
	private static String	tmpMetaFolder	= IntgSrvUtils.reformatFilePath(IntgSrvPropertiesReader
													.getProperty(IntgSrvAppConstants.TMP_META_FOLDER));
	private static String	username		= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_SETUP_SFTP_USER_NAME);
	private static String	password		= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_SETUP_SFTP_PASSWORD);
	private static String	hostname		= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_SETUP_SFTP_HOST_NAME);
	private static String	metafile		= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.META_FILE);
	private static String	extn			= IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.META_FILE_EXTN);
	private static int		port			= Integer.parseInt(IntgSrvPropertiesReader.getProperty(IntgSrvAppConstants.SUPPLIER_SETUP_SFTP_PORT));
	public static String	PUBLISH_ID		= "SUPPLIER_SETUP";

	public void processFiles() {

		Session session = null;
		try {
			String msgDesc = "Started in processing files.. inside processFiles method...";
			traceLogger.info(clazzname, "processFiles", msgDesc);

			session = getSFTPSession();

			List<String> supplierUserFileList = getFileNamesandMoveFiles(supplierUser, session);
			List<String> supplierGroupFileList = getFileNamesandMoveFiles(supplierGroup, session);
			List<String> supplierFolderFileList = getFileNamesandMoveFiles(supplierFolder, session);

			List<String> metaFileList = new ArrayList<String>();

			SimpleDateFormat dateformatyyyyMMdd = new SimpleDateFormat("yyyyMMdd_HHmmsss");
			String dateJob = dateformatyyyyMMdd.format(new Date());
			String epochTime = String.valueOf(System.currentTimeMillis());

			String metaFileName = metafile + "_" + dateJob + "_" + epochTime + extn;

			if (supplierFolderFileList.size() != 0) {
				metaFileList.addAll(supplierFolderFileList);
			}
			if (supplierGroupFileList.size() != 0) {
				metaFileList.addAll(supplierGroupFileList);
			}
			if (supplierUserFileList.size() != 0) {
				metaFileList.addAll(supplierUserFileList);
			}

			String metaFileSrc = tmpMetaFolder + metaFileName;
			String metaFileDestn = inboundFolder + metaFileName;
			if (metaFileList.size() != 0) {
				writeMetaFile(metaFileList, metaFileSrc);
				copyMetaFile(metaFileSrc, metaFileDestn, session);
			}

		} catch (Exception exception) {
			String msgDesc = "Exception in processFiles::" + exception.getMessage();
			traceLogger.info(clazzname, "processFiles", msgDesc);
			IntgSrvUtils.alertByEmail(exception, clazzname, SupplierSetupProcessor.PUBLISH_ID);
		} finally {
			try {
				if(session!=null)
				{
				session.disconnect();
				}
			} catch (Exception exception) {
				String msgDesc = "Exception in disconnecting session::" + exception.getMessage();
				traceLogger.info(clazzname, "processFiles", msgDesc);
				IntgSrvUtils.alertByEmail(exception, clazzname, SupplierSetupProcessor.PUBLISH_ID);
			}
		}
	}

	private void writeMetaFile(List<String> fileNames, String metaFileSrc) throws IOException {

		FileWriter fstream = new FileWriter(metaFileSrc, true);
		BufferedWriter out = new BufferedWriter(fstream);

		for (String fileName : fileNames) {
			out.write(fileName);
			out.newLine();
		}
		// close buffer writer
		out.close();
	}

	private void copyMetaFile(String srcFileString, String destDirString, Session session) throws IOException, JSchException, SftpException {

		ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
		sftp.connect();
		File file = new File(srcFileString);
		InputStream inputStream = new FileInputStream(file);
		sftp.put(inputStream, destDirString);
		sftp.disconnect();
	}

	public Session getSFTPSession() throws JSchException, SftpException {

		JSch conn = new JSch();
		Session session = conn.getSession(username, hostname, port);
		session.setPassword(password);
		session.setConfig("StrictHostKeyChecking", "no");
		session.setConfig("PreferredAuthentications", "publickey,keyboard-interactive,password");
		session.connect();
		IntgSrvUtils.printConsole("Connected SESSION NAME ::: " + session);
		return session;
	}

	public List<String> getFileNamesandMoveFiles(String directoryName, Session session) throws JSchException, SftpException {

		IntgSrvUtils.printConsole("directoryName ::  " + directoryName);
		ChannelSftp sftp = (ChannelSftp) session.openChannel("sftp");
		sftp.connect();
		String fileName = "";
		String srcFile = "";
		String destFile = "";
		List<String> fileNameList = new ArrayList<String>();
		sftp.cd(directoryName);
		Vector<ChannelSftp.LsEntry> list = sftp.ls(directoryName);
		int count = 0;
		for (ChannelSftp.LsEntry entry : list) {

			if (entry.getAttrs().isDir()) {
				continue;
			}
			count++;
			// entry.getLongname();

			fileName = entry.getFilename();
			fileNameList.add(fileName);
			srcFile = directoryName + fileName;
			destFile = inboundFolder + fileName;
			sftp.rename(srcFile, destFile);

		}
		IntgSrvUtils.printConsole("count::" + count);
		sftp.disconnect();
		return fileNameList;
	}

	public static void main(String args[]) {

		SupplierSetupProcessor supplierSetupProcessor = new SupplierSetupProcessor();
		supplierSetupProcessor.processFiles();

	}

}