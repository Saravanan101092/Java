package com.staples.pim.delegate.wercs.steptowercs.retry.runner;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;


public class RunSchedulerWercsRetry  extends RunScheduler {

	@Override
	public void run() {

		System.out.println("Triggered At :"+new Date().toString());
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}

	public static void main(String[] args){
		
		 ApplicationContext context = new FileSystemXmlApplicationContext("file:C:/integrationservicesworkspace/IntegrationServices/configurations/job-Scheduler-WercsRetry.xml");
	}
}
