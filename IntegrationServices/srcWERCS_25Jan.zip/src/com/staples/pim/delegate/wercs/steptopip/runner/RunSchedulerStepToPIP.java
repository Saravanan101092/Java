package com.staples.pim.delegate.wercs.steptopip.runner;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;


public class RunSchedulerStepToPIP extends RunScheduler {

	@Override
	public void run() {

		// TODO Auto-generated method stub
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		// TODO Auto-generated method stub
		return null;
	}

}
