package com.staples.pim.delegate.wercs.steptowercs.retry.processor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.delegate.wercs.databaseprocessor.DatabaseAccessor;
import com.staples.pim.delegate.wercs.databaseprocessor.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.processor.WERCSRestAPIProcessor;
import com.staples.pim.delegate.wercs.steptowercs.runner.RunSchedulerStepToWercs;


public class WercsRegStatusRetryProcessor {

	public void processWercsRegStatusRetry(){
		
		List<MasterTableVO> masterTableVOList = getUpcsToRetry();
		if(masterTableVOList.size()>0){
			Map<String,MasterTableVO> masterTableVOMap = new WERCSRestAPIProcessor().processWercsAPIRequests(masterTableVOList);
			processResponsesFromWercs(masterTableVOMap);
		}
	}
	
	public List<MasterTableVO> getUpcsToRetry(){
		DatabaseAccessor dbAccess = (DatabaseAccessor)RunSchedulerStepToWercs.context.getBean("databaseAccess");
		ResultSet resultSet = dbAccess.getWercsRetryUPCs();
		List<MasterTableVO> masterTableVOList = new ArrayList<MasterTableVO>();
		try {
			while(resultSet.next()){
				MasterTableVO masterTableVO = new MasterTableVO();
				masterTableVO.setUPCNo(resultSet.getString("upc"));
				masterTableVO.setPipid(resultSet.getString("pip_id"));
				masterTableVO.setTranstype(resultSet.getString("transaction_type"));
				masterTableVO.setCreatedDate(resultSet.getTimestamp("created_date"));
				masterTableVO.setPreviousRegistrationStatus(resultSet.getInt("registration_status"));
				masterTableVOList.add(masterTableVO);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return masterTableVOList;
	}
	
	public void processResponsesFromWercs(Map<String,MasterTableVO> masterTableVOs){
		
		//xmls to be sent to step
		Map<String,MasterTableVO> itemsToSTEP = new HashMap<String,MasterTableVO>();
		//rejected xmls to be sent to step
		List<MasterTableVO> rejectedItems = new ArrayList<MasterTableVO>();
		
		for(String upcNo : masterTableVOs.keySet()){
			
			MasterTableVO masterTableVO = masterTableVOs.get(upcNo);
			int registration_Status = masterTableVO.getRegistrationStatus();
			
			if(registration_Status!=-1){
				//if status = 1 send xml to step
				if(registration_Status==1){
					itemsToSTEP.put(upcNo, masterTableVO);
				}else{
					
					//current time
					Calendar currentCalendarTime = Calendar.getInstance();
					//created time
					Calendar createdCalendarTime = Calendar.getInstance();
					createdCalendarTime.setTimeInMillis(masterTableVO.getCreatedDate().getTime());
					int rejectionTimespan = Integer.parseInt(IntgSrvPropertiesReader.getProperty("WERCS_TIMETO_REJECT_ITEM"));
					createdCalendarTime.set(createdCalendarTime.HOUR_OF_DAY, createdCalendarTime.get(createdCalendarTime.HOUR_OF_DAY)+rejectionTimespan);
					
					if(currentCalendarTime.after(createdCalendarTime)){
						//means time span exceeded
						rejectedItems.add(masterTableVO);
					}else{
						
						//previous registration status set as soon as row retrieved from DB
						if(registration_Status!=masterTableVO.getPreviousRegistrationStatus()){
							itemsToSTEP.put(upcNo, masterTableVO);
						}else{
							System.out.println("status unchanged for upc:"+upcNo);
						}
					}
				}
			}
		}
	}
	
	public static void main(String[] args){
		
		Timestamp timeStamp1 = new Timestamp(Calendar.getInstance().getTimeInMillis());
		System.out.println("TimeStamp : "+timeStamp1.toString());
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(timeStamp1.getTime());
		cal.set(cal.HOUR_OF_DAY, cal.get(cal.HOUR_OF_DAY)+168);
		Timestamp timeStamp2 = new Timestamp(cal.getTimeInMillis());
		System.out.println("TimeStamp : "+timeStamp2.toString());
	}
}
