package com.staples.pim.delegate.wercs.steptowercs.runner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionException;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;
import com.staples.pim.base.loader.ContextLoaderFactory;
import com.staples.pim.base.util.IntgSrvUtilConstants;
import com.staples.pim.base.util.IntgSrvUtils;


public class RunSchedulerStepToWercs extends RunScheduler {

	public static ApplicationContext context;
	@Override
	public void run() {

		context = new FileSystemXmlApplicationContext("file:C:\\integrationservicesworkspace\\IntegrationServices\\configurations\\job-StepToWercs.xml");
	    
        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean("stepToWercs");
        
        File inputFolder = new File(IntgSrvUtils.reformatFilePath("/opt/stibo/integration/hotfolder/WERCSIncoming/STEPRegistrationRequest/File_Unprocessed"));
        File[] inputFiles = inputFolder.listFiles();
        
        try {
        	List<Resource> resourcesList = new ArrayList<Resource>();
        	Resource[] resources = new Resource[inputFiles.length];
        	for(int i=0;i<inputFiles.length;i++){
        		resources[i] = new FileSystemResource(inputFiles[i]);
        	}
        	MultiResourceItemReader multiReader =(MultiResourceItemReader)context.getBean("multiResourceReader");
        	multiReader.setResources(resources);
            JobExecution execution = jobLauncher.run(job, new JobParameters());
            System.out.println("Job Exit Status : "+ execution.getStatus());
            List<Throwable> exceptions =execution.getAllFailureExceptions();
            for(Throwable th : exceptions){
            	System.out.println(th.getMessage());
            	th.printStackTrace();
            }
 
        } catch (JobExecutionException e) {
            System.out.println("Job ExamResult failed");
            e.printStackTrace();
        }
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}

	public static void main(String args[]){
		new RunSchedulerStepToWercs().run();
	}
}
