package com.staples.pim.delegate.wercs.piptostep.runner;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;


public class RunSchedulerPIPToStep extends RunScheduler {

	@Override
	public void run() {

		// TODO Auto-generated method stub
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		// TODO Auto-generated method stub
		return null;
	}

}
