package com.staples.pim.delegate.skuflagging.domain;

public class ProductFilterSKUFlagging {

}
