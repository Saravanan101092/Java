
package com.staples.pim.delegate.wholesalers.model;

public class WholesalerSupplierBean {

	private String	vendorName;
	private String	SupplierId;
	private String	SupplierName;
	private String	SupplierMail;

	public String getVendorName() {

		return vendorName;
	}

	public void setVendorName(String vendorName) {

		this.vendorName = vendorName;
	}

	public String getSupplierId() {

		return SupplierId;
	}

	public void setSupplierId(String supplierId) {

		SupplierId = supplierId;
	}

	public String getSupplierName() {

		return SupplierName;
	}

	public void setSupplierName(String supplierName) {

		SupplierName = supplierName;
	}

	public String getSupplierMail() {

		return SupplierMail;
	}

	public void setSupplierMail(String supplierMail) {

		SupplierMail = supplierMail;
	}

}
