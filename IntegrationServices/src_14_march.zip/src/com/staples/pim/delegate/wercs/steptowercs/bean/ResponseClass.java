package com.staples.pim.delegate.wercs.steptowercs.bean;

public class ResponseClass {
	private boolean bError;
	private String sErrorMessage;
	private String sToken;
	public boolean getBError() {
		return bError;
	}
	public void setbError(boolean bError) {
		this.bError = bError;
	}
	public String getsErrorMessage() {
		return sErrorMessage;
	}
	public void setsErrorMessage(String sErrorMessage) {
		this.sErrorMessage = sErrorMessage;
	}
	public String getsToken() {
		return sToken;
	}
	public void setsToken(String sToken) {
		this.sToken = sToken;
	}
	
	
	
	
	
	

}
