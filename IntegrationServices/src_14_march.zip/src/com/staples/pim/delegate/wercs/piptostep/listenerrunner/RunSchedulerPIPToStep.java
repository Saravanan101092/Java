package com.staples.pim.delegate.wercs.piptostep.listenerrunner;

import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oracle.jdbc.pool.OracleDataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.staples.common.errorhandlingframework.ErrorHandlingFrameworkHandler;
import com.staples.common.errorhandlingframework.ErrorHandlingFrameworkICD;
import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.errorhandling.IntgSrvErrorHandlingFrameworkConstants;
import com.staples.pim.base.common.errorhandling.IntgSrvErrorHandlingFrameworkICD;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.base.util.IntgSrvAppConstants;
import com.staples.pim.base.util.IntgSrvUtilConstants;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants;


public class RunSchedulerPIPToStep extends RunScheduler {

	
	/*
	 * Logger Configurations
	 */
	public HashMap<String, String>	ehfItemLogHeadingData						= new HashMap<String, String>();
	
	/*
	 * REQUIRED DIRECTORIES
	 */
	public static String			WERCS_PIP_STEP_INPUT_DIR					= "WERCS_PIP_STEP_INPUT_DIR";
	public static String			WERCS_PIP_STEP_OUTPUT_DIR					= "WERCS_PIP_STEP_OUTPUT_DIR";
	public static String			WERCS_PIP_STEP_REPORT_FILE					= "WERCS_PIP_STEP_REPORT_FILE";
	public static String			WERCS_PIP_STEP_DONE_DIR						= "WERCS_PIP_STEP_DONE_DIR";
	public static String			WERCS_PIP_STEP_BAD_DIR						= "WERCS_PIP_STEP_BAD_DIR";
	public static String			WERCS_PIP_STEP_REPORT_DIR					= "WERCS_PIP_STEP_REPORT_DIR";
	public static String			PUBLISH_ID									= "PIPE101";
	
	/*
	 * JOB NAMES
	 */
	public static String			WERCS_PIP_STEP_JOB							= "wercsPipStepJob";
	
	/*
	 * Feed File information
	 */
	public static String			FEED_FILE_EXTN								= ".xsv";
	public static String			FEED_FILE_NAME_DATE_FORMAT					= "yyyy_MM_dd_HH_mm_ss_SSSSSS";
	public static String			FEED_FILE_BEGIN								= IntgSrvPropertiesReader.getProperty("WERCS_PIP_STEP_FEED_FILE_BEGIN");
	public static String			infoLogString;
	
	public static OracleDataSource datasource;
	
	public OracleDataSource getDatasource() {

		return datasource;
	}

	public void setDatasource(OracleDataSource datasource) {

		this.datasource = datasource;
	}
	
	
	@Override
	public void run() {}
	
	/**
	 * Will return the list of files only if it is a file, begins with "FEED_FILE_BEGIN", and ends with "FEED_FILE_EXTN" from list of sourceList files. 
	 */
	private List<File> getPipStepContractFeeds(List<File> sourceList) {

		List<File> contractFileList = new ArrayList<File>();

		for (File file : sourceList) 
		{
			String fileName = file.getName();
			if (file.isFile() && fileName.startsWith(FEED_FILE_BEGIN) && fileName.endsWith(FEED_FILE_EXTN)) {
				contractFileList.add(file);
			}
		}
		return contractFileList;
	}
	

	/**
	 * Creating required directories if not exist
	 */
	protected void createWriterOutputDir(String directoryName)
	{

		File directory = new File(directoryName);
		if (!directory.exists()) 
		{
			if (directory.mkdirs())
				IntgSrvUtils.printConsole("RunSchedulerPipToStep.createWriterOutputDirs | Dir CREATED:" + directoryName);
		}
	}
	

	
	/**
	 * To get index of "_"  for getting file name for sorting
	 */
	
	public static int findIndexOf(String source, String pattern, int occurence) {
		
		/**
		 *  Source string will be the string on which operation is done.
		 *  Pattern will be whose occurrence we want (here "_" ) 
		 *  Occurrence will be at which occurring value we want
		 *  We will be returning the position of that pattern occurring in the source string
		 */

		int count = 0, current_position = 0, required_position = 0;

		while (count < occurence) {
			current_position = source.indexOf(pattern);
			if (current_position > -1) {
				source = source.substring(current_position + 1);
				required_position += current_position + 1;
				count++;
			} else {
				return -1;
			}
		}
		return required_position - 1;
	}
	
	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}
	

}
