/**
 * -----------------------------------------------------------------------
 * STAPLES, INC
 * -----------------------------------------------------------------------
 * (C) Copyright 2007 Staples, Inc.          All rights reserved.
 *
 * NOTICE:  All information contained herein or attendant hereto is,
 *          and remains, the property of Staples Inc.  Many of the
 *          intellectual and technical concepts contained herein are
 *          proprietary to Staples Inc. Any dissemination of this
 *          information or reproduction of this material is strictly
 *          forbidden unless prior written permission is obtained
 *          from Staples Inc.
 * -----------------------------------------------------------------------
 */
/*
 * File name     :   
 * Creation Date :   
 * @author  
 * @version 1.0
 */ 

package com.staples.pim.delegate.skuflagging.listenerrunner;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;

public class SKUFlaggingRunScheduler extends RunScheduler {
	
	public   void processOfJobRunning(Object obj)
	{
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {
		// TODO Auto-generated method stub
		return null;
	}

	//@Override
	// protected void proceedToTheDestination(StepTransmitterBean transmitter) {
		// TODO Auto-generated method stub
		
	// }

	 

}
