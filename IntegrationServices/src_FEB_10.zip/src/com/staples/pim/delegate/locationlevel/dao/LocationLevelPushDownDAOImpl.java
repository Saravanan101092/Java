/**
 * -----------------------------------------------------------------------
 * STAPLES, INC
 * -----------------------------------------------------------------------
 * (C) Copyright 2007 Staples, Inc.          All rights reserved.
 *
 * NOTICE:  All information contained herein or attendant hereto is,
 *          and remains, the property of Staples Inc.  Many of the
 *          intellectual and technical concepts contained herein are
 *          proprietary to Staples Inc. Any dissemination of this
 *          information or reproduction of this material is strictly
 *          forbidden unless prior written permission is obtained
 *          from Staples Inc.
 * -----------------------------------------------------------------------
 */
/*
 * File name     :  LocationLevelPushDownWriter.java
 * Creation Date :  7/13/2015 
 * @author       :  Sima Zaslavsky
 * @version 1.0
 */ 

package com.staples.pim.delegate.locationlevel.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.staples.pim.base.common.exception.IntgSrvBatchException;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.persistence.connection.IIntgSrvConnConstants;
import com.staples.pim.base.persistence.util.IntgSrvJDBCUtils;
import com.staples.pim.base.util.IntgSrvAppConstants;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.locationlevel.bean.StepLocationLevelPushDownData;

public class LocationLevelPushDownDAOImpl {


	/**
	 * Used for logging
	 */	 
	  protected static IntgSrvLogger logger = null;
	/**
	 * Data Base Info for JNDI lookup
	 */
	 @SuppressWarnings("unused")
	private String dbInfoRet = IIntgSrvConnConstants.AS400SERVER_GALAXY_PIM;
	 
	private String dbInfoScc = IIntgSrvConnConstants.AS400SERVER_SUNBEAM_PIM;
	 
	/**
	* Connection Object
	*/
	private Connection conn = null;
		
	/**
	* Default Constructor
	*/
	public LocationLevelPushDownDAOImpl() 
	{
		super();
			 
	}
	/**
	* Constructor
	* 
	* @param conn - Connection Object
	*/
	public LocationLevelPushDownDAOImpl(Connection conn)
	{
		super();
		this.conn = conn;
	}
		
	/**
	* Business Logic starts here
	*/	
	
	/**
	 * The method invokes the stored procedure to update the location level attributes on iSeries server
	 * @return List of  
	 * @throws IntgSrvBatchException 
	 */
	@SuppressWarnings("rawtypes")
	public List locationLevelPushDownRetail(StepLocationLevelPushDownData inputTO) throws IntgSrvBatchException
	{
		logger.info("In locationLevelUpdateRetChannel: Fetching New Items Created..."); 
		
		StepLocationLevelPushDownData stepLocationLevelTO = inputTO; 
		
		IntgSrvJDBCUtils jdbcUtils =
			new IntgSrvJDBCUtils(
					conn, 
					stepLocationLevelTO, 
					IntgSrvUtils.prepareQuery(stepLocationLevelTO.getProcNameRet()),
					IIntgSrvConnConstants.AS400SERVER_GALAXY_PIM) 
		{
			 
			/*
			 * Prepare the Prepared Statement  
			 */
			   public CallableStatement prepareCall(String query, CallableStatement stmt) throws SQLException
			   {
				   StepLocationLevelPushDownData dataTO = (StepLocationLevelPushDownData) data;			   		
			   		stmt.setString(1, dataTO.getKeyLine());
			   			IntgSrvUtils.printConsole("Input KeyLIne is " + (dataTO.getKeyLine()).toUpperCase());
			   		stmt.setString(2, dataTO.getDataline1());
			   			IntgSrvUtils.printConsole("Input dataLine is " + (dataTO.getDataline1()).toUpperCase());
			   		stmt.setString(3, dataTO.getDataline2());
			   		stmt.setString(4, dataTO.getDataline3());
			   		stmt.setString(5, dataTO.getDataline4());
			   		stmt.setString(6, dataTO.getDataline5());
			   		stmt.setString(7, dataTO.getDataline6());
			   		stmt.setString(8, dataTO.getDataline7());
			   		stmt.setString(9, dataTO.getDataline8());
			   		stmt.setString(10, dataTO.getDataline9());
			   		stmt.setString(11, dataTO.getDataline10());
			   		stmt.setString(12, dataTO.getDataline11());
			   		stmt.setString(13, dataTO.getDataline12());
			   		
			   		stmt.registerOutParameter(14, java.sql.Types.CHAR);
					stmt.registerOutParameter(15, java.sql.Types.CHAR);
					stmt.registerOutParameter(16, java.sql.Types.CHAR);
					stmt.registerOutParameter(17, java.sql.Types.CHAR);
					stmt.registerOutParameter(18, java.sql.Types.CHAR);
					stmt.registerOutParameter(19, java.sql.Types.CHAR);
					stmt.registerOutParameter(20, java.sql.Types.CHAR);
					stmt.registerOutParameter(21, java.sql.Types.CHAR);
					stmt.registerOutParameter(22, java.sql.Types.CHAR);
					stmt.registerOutParameter(23, java.sql.Types.CHAR);
					stmt.registerOutParameter(24, java.sql.Types.CHAR);
					stmt.registerOutParameter(25, java.sql.Types.CHAR);
					stmt.registerOutParameter(26, java.sql.Types.CHAR);
					stmt.registerOutParameter(27, java.sql.Types.CHAR);
					stmt.registerOutParameter(28, java.sql.Types.CHAR);					
			   		
			   		return stmt;
			   }	
			/*
			 * Maps the ResultSet to the Transfer Object
			 */
			@SuppressWarnings("unchecked")
			public List resultMapper(CallableStatement stmt) throws SQLException
			{				
				List  listOfStrings  = new ArrayList();
				try
				{   
					listOfStrings.add(0, ((String) stmt.getObject(1)).trim());
					listOfStrings.add(1, ((String) stmt.getObject(2)).trim());
					listOfStrings.add(2, ((String) stmt.getObject(3)).trim());
					listOfStrings.add(3, ((String) stmt.getObject(4)).trim());
					listOfStrings.add(4, ((String) stmt.getObject(5)).trim());
					listOfStrings.add(5, ((String) stmt.getObject(6)).trim());
					listOfStrings.add(6, ((String) stmt.getObject(7)).trim());
					listOfStrings.add(7, ((String) stmt.getObject(8)).trim());
					listOfStrings.add(8, ((String) stmt.getObject(9)).trim());
					listOfStrings.add(9, ((String) stmt.getObject(11)).trim());
					listOfStrings.add(10, ((String) stmt.getObject(11)).trim());
					listOfStrings.add(11, ((String) stmt.getObject(12)).trim());
					listOfStrings.add(12, ((String) stmt.getObject(13)).trim());
					listOfStrings.add(13, ((String) stmt.getObject(14)).trim());
					listOfStrings.add(14, ((String) stmt.getObject(15)).trim());
					
				}
				catch(SQLException sqlexc)
				{
					//   logger.fatal("mapResults_4 :: Unable to extract object from the statement. " + sqlexc.getMessage(), sqlexc);
					sqlexc.printStackTrace();
					//throw new IntgSrvBatchException(IntgSrvAppConstants.UNABLE_EXTRACT_OBJECT_FROM_CALLABLE_STATEMENT_ERROR_MSG_TEXT + 
							//IntgSrvAppConstants.TILDA_DELIM    +
												   //sqlexc.getMessage().trim() +
												  // IntgSrvAppConstants.TILDA_DELIM);
				}
				
				return listOfStrings;
			}
		};
		try
		{
    		/*
    		 * Execute Query
    		 */
    		return (List)jdbcUtils.execute();
    		
 		} 
		catch (Exception ex)
		{
 			throw new IntgSrvBatchException("Exception trying to Update location LevelUpdateRetChannel", ex);
		}
		 
	}  
	
	/**
	 * The method invokes the stored procedure to update the location level attributes on iSeries server
	 * @return List of  
	 * @throws IntgSrvBatchException 
	 */
	@SuppressWarnings("rawtypes")
	public List locationLevelPushDownNad(StepLocationLevelPushDownData inputTO) throws IntgSrvBatchException
	{
		logger.info("In locationLevelUpdateRetChannel: Fetching New Items Created..."); 
		
		StepLocationLevelPushDownData stepLocationLevelTO = inputTO; 
		
		IntgSrvJDBCUtils jdbcUtils =
			new IntgSrvJDBCUtils(
					conn, 
					stepLocationLevelTO, 
					IntgSrvUtils.prepareQuery(stepLocationLevelTO.getProcNameNad()),
					IIntgSrvConnConstants.AS400SERVER_SUNBEAM_PIM) 
		{
			 
			/*
			 * Prepare the Prepared Statement  
			 */
			   public CallableStatement prepareCall(String query, CallableStatement stmt) throws SQLException
			   {
				   StepLocationLevelPushDownData dataTO = (StepLocationLevelPushDownData) data;			   		
			   		stmt.setString(1, dataTO.getKeyLine());
			   			IntgSrvUtils.printConsole("Input KeyLIne is " + (dataTO.getKeyLine()).toUpperCase());
			   		stmt.setString(2, dataTO.getDataline1());
			   			IntgSrvUtils.printConsole("Input dataLine is " + (dataTO.getDataline1()).toUpperCase());
			   		stmt.setString(3, dataTO.getDataline2());
			   		stmt.setString(4, dataTO.getDataline3());
			   		stmt.setString(5, dataTO.getDataline4());
			   		stmt.setString(6, dataTO.getDataline5());
			   		stmt.setString(7, dataTO.getDataline6());
			   		stmt.setString(8, dataTO.getDataline7());
			   		stmt.setString(9, dataTO.getDataline8());
			   		stmt.setString(10, dataTO.getDataline9());
			   		stmt.setString(11, dataTO.getDataline10());
			   		stmt.setString(12, dataTO.getDataline11());
			   		stmt.setString(13, dataTO.getDataline12());
			   		
			   		stmt.registerOutParameter(14, java.sql.Types.CHAR);
					stmt.registerOutParameter(15, java.sql.Types.CHAR);
					stmt.registerOutParameter(16, java.sql.Types.CHAR);
					stmt.registerOutParameter(17, java.sql.Types.CHAR);
					stmt.registerOutParameter(18, java.sql.Types.CHAR);
					stmt.registerOutParameter(19, java.sql.Types.CHAR);
					stmt.registerOutParameter(20, java.sql.Types.CHAR);
					stmt.registerOutParameter(21, java.sql.Types.CHAR);
					stmt.registerOutParameter(22, java.sql.Types.CHAR);
					stmt.registerOutParameter(23, java.sql.Types.CHAR);
					stmt.registerOutParameter(24, java.sql.Types.CHAR);
					stmt.registerOutParameter(25, java.sql.Types.CHAR);
					stmt.registerOutParameter(26, java.sql.Types.CHAR);
					stmt.registerOutParameter(27, java.sql.Types.CHAR);
					stmt.registerOutParameter(28, java.sql.Types.CHAR);					
			   		
			   		return stmt;
			   }	
			/*
			 * Maps the ResultSet to the Transfer Object
			 */
			@SuppressWarnings("unchecked")
			public List resultMapper(CallableStatement stmt) throws SQLException
			{				
				List  listOfStrings  = new ArrayList();
				try
				{   
					listOfStrings.add(0, ((String) stmt.getObject(1)).trim());
					listOfStrings.add(1, ((String) stmt.getObject(2)).trim());
					listOfStrings.add(2, ((String) stmt.getObject(3)).trim());
					listOfStrings.add(3, ((String) stmt.getObject(4)).trim());
					listOfStrings.add(4, ((String) stmt.getObject(5)).trim());
					listOfStrings.add(5, ((String) stmt.getObject(6)).trim());
					listOfStrings.add(6, ((String) stmt.getObject(7)).trim());
					listOfStrings.add(7, ((String) stmt.getObject(8)).trim());
					listOfStrings.add(8, ((String) stmt.getObject(9)).trim());
					listOfStrings.add(9, ((String) stmt.getObject(11)).trim());
					listOfStrings.add(10, ((String) stmt.getObject(11)).trim());
					listOfStrings.add(11, ((String) stmt.getObject(12)).trim());
					listOfStrings.add(12, ((String) stmt.getObject(13)).trim());
					listOfStrings.add(13, ((String) stmt.getObject(14)).trim());
					listOfStrings.add(14, ((String) stmt.getObject(15)).trim());
					
				}
				catch(SQLException sqlexc)
				{
					//   logger.fatal("mapResults_4 :: Unable to extract object from the statement. " + sqlexc.getMessage(), sqlexc);
					sqlexc.printStackTrace();
					//throw new IntgSrvBatchException(IntgSrvAppConstants.UNABLE_EXTRACT_OBJECT_FROM_CALLABLE_STATEMENT_ERROR_MSG_TEXT + 
							//IntgSrvAppConstants.TILDA_DELIM    +
												   //sqlexc.getMessage().trim() +
												  // IntgSrvAppConstants.TILDA_DELIM);
				}
				
				return listOfStrings;
			}
		};
		try
		{
    		/*
    		 * Execute Query
    		 */
    		return (List)jdbcUtils.execute();
    		
 		} 
		catch (Exception ex)
		{
 			throw new IntgSrvBatchException("Exception trying to Update location LevelUpdateRetChannel", ex);
		}
		 
	}  


}
