package com.staples.pim.delegate.wercs.mail.runner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.wercs.mail.WercsMailNotification;


public class RunSchedulerMailNotifications  extends RunScheduler {

	public static ApplicationContext context;
	
	@Override
	public void run() {
		
		context=new FileSystemXmlApplicationContext("file:"+IntgSrvUtils.reformatFilePath(IntgSrvUtils.getConfigDir()+"/wercsDatabase.xml"));
		new WercsMailNotification().processMailNotifications();
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}

}
