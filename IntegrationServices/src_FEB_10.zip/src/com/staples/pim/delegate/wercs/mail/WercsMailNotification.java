package com.staples.pim.delegate.wercs.mail;

import java.util.Calendar;
import java.util.List;

import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.delegate.wercs.common.SBDatabaseHandlingService;
import com.staples.pim.delegate.wercs.mail.runner.RunSchedulerMailNotifications;
import com.staples.pim.delegate.wercs.model.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.runner.RunSchedulerStepToWercs;


public class WercsMailNotification {

	private static final String					TRACELOGGER_WERCS_WERCSRETRY			= "tracelogger.wercs.wercsretry";
	static IntgSrvLogger						logger									= IntgSrvLogger
			.getInstance(TRACELOGGER_WERCS_WERCSRETRY);
	
	public void sendRemainderMail(){
		
	}
	
	public void sendFinalNotificationMail(){
		
	}
	
	public void sendRejectedNotification(){
		
	}
	
	public void sendInitialNotice(){
		
	}
	
	public List<MasterTableVO> getRegStatusDetailsFromDB(){
		SBDatabaseHandlingService dbAccess = (SBDatabaseHandlingService)RunSchedulerMailNotifications.context.getBean(SBDatabaseHandlingService.DBACCESS);
		List<MasterTableVO> mailNotificationItems=dbAccess.getRulesTrippedDetails(logger);
		return mailNotificationItems;
	}
	
	public List<MasterTableVO> getRulesTrippedDetailsFromDB(){
		SBDatabaseHandlingService dbAccess = (SBDatabaseHandlingService)RunSchedulerMailNotifications.context.getBean(SBDatabaseHandlingService.DBACCESS);
		List<MasterTableVO> rulesTrippedItems=dbAccess.getRulesTrippedDetails(logger);
		return rulesTrippedItems;
	}
	
	public void sendRulesTrippedMail(List<MasterTableVO> rulesTrippedItems){
		//Send rules tripped mail
	}
	
	public void processRulesTrippedMailNotifications(){
		
		List<MasterTableVO> rulesTrippedItems = getRegStatusDetailsFromDB();
		sendRulesTrippedMail(rulesTrippedItems);
	}
	
	public void processMailNotificationRegStatus(){
		
	}
	
	public void processMailNotifications(){
		System.out.println("process mail notifications");
		Calendar currentTime = Calendar.getInstance();
		int currentHour = currentTime.get(Calendar.HOUR_OF_DAY);
		if((currentHour>18) &&(currentHour<20)){
			processMailNotificationRegStatus();
		}
		processRulesTrippedMailNotifications();
	}
}
