package com.staples.pim.delegate.datamigration.wayfair.activeskuupdate;

import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.CONTEXT_ID_VALUE;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.EXPORT_CONTEXT_VALUE;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.WAYFAIR_ACTIVESKU_OUTPUT_FOLDER;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.WORKSPACE_ID_VALUE;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.staples.pcm.stepcontract.beans.NameType;
import com.staples.pcm.stepcontract.beans.ObjectFactory;
import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.productupdate.runner.ProductInboundScheduler;

/**
 * @author 843868
 *
 */
public class ActiveSKUProcessor {

	public static final String WAYFAIR_ACTIVESKU_INSTANCENO = "17";

	public static final String XML_EXTENSION = ".xml";

	public static final String UNDERSCORE = "_";

	public static final String WAYFAIR_ACTIVESKU_HEADER = "wayfair.activesku.header";

	public static final String WAYFAIR_ACTIVESKU_DELIMITER = "wayfair.activesku.delimiter";

	public static final String ITM_BUSINESSUNIT = "ITM_BusinessUnit";

	public static final String PRODUCTID_PREFIX="DMItem-";

	public static final String VEN_ITEMNUMBER = "VEN_ItemNmb";

	public static final String ITM_ACTIVEURL = "ITM_ActiveURL";

	public static final String WAYFAIRITEMS = "WayFairItems";

	public static final String A1451_STR = "A0569";

	public static final String A0501_STR = "A0501";

	public static final String delimiter = IntgSrvPropertiesReader.getProperty(WAYFAIR_ACTIVESKU_DELIMITER);

	public static final String headerString = IntgSrvPropertiesReader.getProperty(WAYFAIR_ACTIVESKU_HEADER);

	public static final String ACTIVESKU_REFERENCE_FOLDER_CURRENT_PATH = "/opt/stibo/SpringBatch/Reference/wayfairlookup/activesku/current";

	public static final String ACTIVESKU_REFERENCE_FOLDER_OLD_PATH = "/opt/stibo/SpringBatch/Reference/wayfairlookup/activesku/old";

	public static final String[] headers = headerString.split(delimiter, -1);

	public static final String ACTIVESKU_FILEDONE_FOLDER = "/opt/stibo/integration/hotfolder/WayFairIncoming/ActiveSKU/File_Done/";

	public static final String ACTIVESKU_FILEUNPROCESSED_FOLDER = "/opt/stibo/integration/hotfolder/WayFairIncoming/ActiveSKU/File_Unprocessed/";

	public static final String FREEFORM_TRACELOGGER_ACTIVESKU = "tracelogger.wayfairactivesku";
	
	public static final String MAX_RECORDS_PER_FILE = "wayfair.activesku.maxrecordsperfile"; 

	static IntgSrvLogger						logger		= IntgSrvLogger
			.getInstance(FREEFORM_TRACELOGGER_ACTIVESKU);

	public ObjectFactory objectFactory;

	/**
	 * Main method read hotfolder, sort and check for files
	 */
	public void wayfairActiveSKUProcessor(){
		File folder = new File(IntgSrvUtils.reformatFilePath(ACTIVESKU_FILEUNPROCESSED_FOLDER));
		File[] files=DatamigrationCommonUtil.sortFilesBasedOnFIFO(folder, ProductInboundScheduler.PUBLISH_ID);
		for(int i=0;i<files.length;i++){
			logger.info(new Date().toString()+" Processing file : "+files[i].getName());
			readIncomingFile(files[i]);
		}
	}

	/**
	 * @param newFile
	 * @param referenceFile
	 * 
	 * process delta feeds
	 */
	public void processDeltaFeed(File newFile, File referenceFile){

		Set<String> oldFileRecords;
		Set<String> newFileRecords;
		Map<String, Set<String>> deltaRecords = null;

		//get delta feed by comparing input files new and old
		logger.info("generating delta feed from input files");
		deltaRecords = DatamigrationCommonUtil.getDeltaFeedFromNewAndOldFiles(newFile,referenceFile,logger);

		oldFileRecords = deltaRecords.get(DatamigrationAppConstants.WAYFAIR_REFERENCE_OLD);
		newFileRecords = deltaRecords.get(DatamigrationAppConstants.WAYFAIR_REFERENCE_CURRENT);

		//remove modified records
		oldFileRecords = removeModifiedRecordsFromDeletedRecordsActiveSKU(newFileRecords,oldFileRecords);
		logger.info("Delta generation complete. Deleted records="+oldFileRecords.size()+" New records="+newFileRecords.size());

		//get records in a map
		Map<String, List<Map<String, String>>> allRecords = DatamigrationCommonUtil.getSetAsMaps(newFileRecords,delimiter,headers,logger,newFile);

		//get deleted records as map
		Map<String, List<Map<String, String>>> deletedRecords = DatamigrationCommonUtil.getSetAsMaps(oldFileRecords,delimiter,headers,logger,newFile);

		//create STEPProductInformation object
		if((!allRecords.isEmpty()) || (!deletedRecords.isEmpty())) {
		logger.info("creating STEP xml from delta NewRecords="+allRecords.size()+" DeletedRecords="+deletedRecords.size());
		STEPProductInformation stepPrdInfo = createDeltaSTEPProductInformation(allRecords,deletedRecords);

		//copy input file to reference folder for future reference and delta creation
		DatamigrationCommonUtil.copyNewFileToReferenceFolder(newFile,ACTIVESKU_REFERENCE_FOLDER_CURRENT_PATH, logger);

		//marshall and send output file
		logger.info("generating and sending Step xml.");
		File outputFile = DatamigrationCommonUtil.marshallObject(stepPrdInfo, newFile, WAYFAIR_ACTIVESKU_OUTPUT_FOLDER, ProductInboundScheduler.PUBLISH_ID);
		
		DatamigrationCommonUtil.sendFile(outputFile, newFile, ACTIVESKU_FILEDONE_FOLDER,WAYFAIR_ACTIVESKU_INSTANCENO , true, ProductInboundScheduler.PUBLISH_ID);
		logger.info("Step xml sent to step hotfolder successfully");
		}else{
			logger.info("File comparison yielded no delta. No step xml for Activesku feed generated.");
		}
	}


	/**
	 * @param file
	 * 
	 * read input files
	 */
	public void readIncomingFile(File file){

		objectFactory = new ObjectFactory();

		//get reference file
		logger.info("getting reference file from reference folders.");
		File referenceFile = DatamigrationCommonUtil.getReferenceFile(ACTIVESKU_REFERENCE_FOLDER_CURRENT_PATH,ACTIVESKU_REFERENCE_FOLDER_OLD_PATH);

		//if reference file is not available, then feed is considered as onetime
		if(referenceFile!=null){
			logger.info("Got the reference file : "+referenceFile.getName());
			processDeltaFeed(file,referenceFile);
		}else{
			logger.warn("Reference file could not be found.");
			processOneTimeFeed(file);
		}
	}

	/**
	 * @param newFile
	 * @param oldFile
	 * @return
	 * 
	 * remove modified records from deleted feed
	 */
	public Set<String> removeModifiedRecordsFromDeletedRecordsActiveSKU(Set<String> newFile, Set<String> oldFile){

		String[] newFileValues;
		Map<String,String> newFileRecordAsMap;
		Set<String> modifiedRecords = new HashSet<String>();

		//parse through new file records
		for(String newFileRecord : newFile){
			newFileValues = newFileRecord.split(delimiter, -1);
			newFileRecordAsMap = DatamigrationCommonUtil.getRecordAsMap(headers, newFileValues, logger);
			if(newFileRecordAsMap!=null){
				String ID= newFileRecordAsMap.get(VEN_ITEMNUMBER);
				for(String oldFileRecord : oldFile){

					//if both lists contain same ID, then it is not deleted but it is modified
					if(oldFileRecord.contains(ID)){
						modifiedRecords.add(newFileRecord);
					}
				}
			}
		}
		logger.info("No of modified records="+modifiedRecords.size());
		//remove modifed records from oldfile records
		oldFile.removeAll(modifiedRecords);
		return oldFile;
	}

	/**
	 * @param filebeingprocessed
	 * 
	 * process one time feed
	 */
	public void processOneTimeFeed(File filebeingprocessed){
		DatamigrationCommonUtil.printConsole("PROCESSING FILE.."+filebeingprocessed.getName());
		FileReader fileReader;
		String tempString;
		int lineno=0;
		String[] values;
		int fileCount=0;
		int maxRecordsPerFile = Integer.parseInt(IntgSrvPropertiesReader.getProperty(MAX_RECORDS_PER_FILE));
		List<Map<String,String>> quillRecordsList = new ArrayList<Map<String,String>>();
		List<Map<String,String>> dotcomRecordsList = new ArrayList<Map<String,String>>();
		Map<String,String> recordAsMap = null;

		try {
			fileReader = new FileReader(filebeingprocessed.getPath());
			BufferedReader br = new BufferedReader(fileReader);

			//parse line by line
			while ((tempString = br.readLine()) != null) {
				if(!tempString.equals(DatamigrationAppConstants.EMPTY_STR)){

					//get line as a map with headers
					values = tempString.split(delimiter, -1);
					recordAsMap = DatamigrationCommonUtil.getRecordAsMap(headers, values, logger);

					if(recordAsMap!=null){
						//add quill records and dotcom records separately
						if(recordAsMap.get(ITM_BUSINESSUNIT).equalsIgnoreCase(DatamigrationAppConstants.WAYFAIR_QUILL_HIERARCHYCODE)){
							quillRecordsList.add(recordAsMap);
						}else if(recordAsMap.get(ITM_BUSINESSUNIT).equalsIgnoreCase(DatamigrationAppConstants.WAYFAIR_DOTCOM_HIERARCHYCODE)){
							dotcomRecordsList.add(recordAsMap);
						}
					}else{
						logger.error("Record omitted. Incorrect no of values :"+tempString);
						DatamigrationCommonUtil.appendWriterFile(filebeingprocessed.getParentFile().getParentFile() + "/Report/Report_" + filebeingprocessed.getName(), tempString
								+ "~Has incorrect number of Values in record :"+values.length);
					}
					
					//each file shall only contain 50000 records
					if((quillRecordsList.size()+dotcomRecordsList.size())>=maxRecordsPerFile){
						fileCount++;
						logger.info("Records limit per file reached. Creating Step xml no:"+fileCount);
						//create STEP xml and transfer
						createAndSendSTEPXml(quillRecordsList,dotcomRecordsList,filebeingprocessed,fileCount,false);
						quillRecordsList.clear();
						dotcomRecordsList.clear();
					}
				}
				lineno++;
//				DatamigrationCommonUtil.printConsole(lineno);
			}
			br.close(); fileReader.close();

			//copy file to reference folder for future reference
			DatamigrationCommonUtil.copyNewFileToReferenceFolder(filebeingprocessed,ACTIVESKU_REFERENCE_FOLDER_CURRENT_PATH,logger);


			if((quillRecordsList.size()+dotcomRecordsList.size())>0){
				fileCount++;
				//create STEP xml and transfer
				logger.info("creating final STEP xml");
				createAndSendSTEPXml(quillRecordsList, dotcomRecordsList, filebeingprocessed,fileCount,true);
			}

			DatamigrationCommonUtil.printConsole("All records processed..");

		}catch(Exception e){
			e.printStackTrace();
			logger.info("Exception while processing file : "+filebeingprocessed.getName()+" : "+e.getMessage());
		}
	}

	/**
	 * @param quillRecords
	 * @param dotcomRecords
	 * @param filebeingProcessed
	 * @param fileCount
	 * @param isFileMoveActive
	 * 
	 * create and transfer STEP xml 
	 */
	public void createAndSendSTEPXml(List<Map<String, String>> quillRecords,List<Map<String, String>> dotcomRecords, File filebeingProcessed, int fileCount, boolean isFileMoveActive){

		//create STEPProductInformation Object
		STEPProductInformation stepPrdInfo = createOnetimeSTEPProductInformation(quillRecords, dotcomRecords);

		//marshall object
		String filename = filebeingProcessed.getName();
		filename = filename.substring(0, filename.length()-4)+UNDERSCORE+fileCount+XML_EXTENSION;
		File outputFile = DatamigrationCommonUtil.marshallObject(stepPrdInfo, new File(filename), WAYFAIR_ACTIVESKU_OUTPUT_FOLDER, ProductInboundScheduler.PUBLISH_ID);

		//transfer file to STEP hotfolder
		logger.info("Sending file to SFTP");
		DatamigrationCommonUtil.sendFile(outputFile, filebeingProcessed, ACTIVESKU_FILEDONE_FOLDER, WAYFAIR_ACTIVESKU_INSTANCENO, isFileMoveActive, ProductInboundScheduler.PUBLISH_ID);
	}

	/**
	 * @param quillRecords
	 * @param dotcomRecords
	 * @return
	 * 
	 * create STEPProductInformation object for onetimefeed
	 */
	public STEPProductInformation createOnetimeSTEPProductInformation(List<Map<String, String>> quillRecords,List<Map<String, String>> dotcomRecords){


		STEPProductInformation stepPrdInfo = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

		//add quill products
		for(Map<String,String> thisRecord : quillRecords){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			
//			Commented based on krishna request
//			NameType name = objectFactory.createNameType();
//			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
//			product.getName().add(name);
			
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A1451_STR);
			value.setContent(DatamigrationAppConstants.Y_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		//add dotcom products
		for(Map<String,String> thisRecord : dotcomRecords){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			
//			Commented based on krishna request
//			NameType name = objectFactory.createNameType();
//			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
//			product.getName().add(name);
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A0501_STR);
			value.setContent(DatamigrationAppConstants.Y_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		stepPrdInfo.setProducts(products);
		stepPrdInfo.setExportTime(DatamigrationCommonUtil.getCurrentDateForSTEP()); // Current
		stepPrdInfo.setContextID(CONTEXT_ID_VALUE); // Hard coded value
		stepPrdInfo.setExportContext(EXPORT_CONTEXT_VALUE);// Hard coded value
		stepPrdInfo.setWorkspaceID(WORKSPACE_ID_VALUE);// Hard coded value
		return stepPrdInfo;

	}

	/**
	 * @param newRecords
	 * @param deletedRecords
	 * @return
	 * 
	 * create STEPProductInformation object for delta feed
	 */
	public STEPProductInformation createDeltaSTEPProductInformation(Map<String, List<Map<String, String>>> newRecords, Map<String, List<Map<String, String>>> deletedRecords){

		STEPProductInformation stepPrdInfo = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

		//Add new Products
		//add quill products
		for(Map<String,String> thisRecord : newRecords.get(DatamigrationAppConstants.WAYFAIR_QUILL_HIERARCHYCODE)){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			
//			Commented based on krishna request
//			NameType name = objectFactory.createNameType();
//			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
//			product.getName().add(name);
			
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A1451_STR);
			value.setContent(DatamigrationAppConstants.Y_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		//add dotcom products
		for(Map<String,String> thisRecord : newRecords.get(DatamigrationAppConstants.WAYFAIR_DOTCOM_HIERARCHYCODE)){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			
//			Commented based on krishna request
//			NameType name = objectFactory.createNameType();
//			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
//			product.getName().add(name);
			
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A0501_STR);
			value.setContent(DatamigrationAppConstants.Y_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		//Add deleted  quill records
		for(Map<String,String> thisRecord : deletedRecords.get(DatamigrationAppConstants.WAYFAIR_QUILL_HIERARCHYCODE)){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			NameType name = objectFactory.createNameType();
			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.getName().add(name);
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A1451_STR);
			value.setContent(DatamigrationAppConstants.N_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		//add deleted dotcom products
		for(Map<String,String> thisRecord : deletedRecords.get(DatamigrationAppConstants.WAYFAIR_DOTCOM_HIERARCHYCODE)){
			ProductType product = objectFactory.createProductType();
			product.setID(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.setUserTypeID(DatamigrationAppConstants.ITEM);
			product.setParentID(WAYFAIRITEMS);
			product.setSelected(false);
			product.setReferenced(true);
			NameType name = objectFactory.createNameType();
			name.setContent(PRODUCTID_PREFIX+thisRecord.get(VEN_ITEMNUMBER));
			product.getName().add(name);
			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();
			value.setAttributeID(A0501_STR);
			value.setContent(DatamigrationAppConstants.N_STR);
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		stepPrdInfo.setProducts(products);
		stepPrdInfo.setExportTime(DatamigrationCommonUtil.getCurrentDateForSTEP()); // Current
		stepPrdInfo.setContextID(CONTEXT_ID_VALUE); // Hard coded value
		stepPrdInfo.setExportContext(EXPORT_CONTEXT_VALUE);// Hard coded value
		stepPrdInfo.setWorkspaceID(WORKSPACE_ID_VALUE);// Hard coded value
		return stepPrdInfo;

	}

	public static void main(String[] args) {
		ActiveSKUProcessor activeskuprocessor = new ActiveSKUProcessor();
		activeskuprocessor.wayfairActiveSKUProcessor();
	}

}
