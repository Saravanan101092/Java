package com.staples.pim.delegate.datamigration.wayfair.categoryspecificattributeupdate;

import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.CONTEXT_ID_VALUE;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.EMPTY_STR;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.EXPORT_CONTEXT_VALUE;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.WORKSPACE_ID_VALUE;
import static com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants.REFERENCE_FILE_DELIMITER;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.staples.pcm.stepcontract.beans.ObjectFactory;
import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.datamigration.utils.DatamigrationAppConstants;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.productupdate.runner.ProductInboundScheduler;

public class CategorySpecificAttributeInboundProcessor {

	public static final String FREEFORM_TRACELOGGER_ATTRIBUTEFEED = "tracelogger.wayfairattributefeed";

	static IntgSrvLogger logger	= IntgSrvLogger.getInstance(FREEFORM_TRACELOGGER_ATTRIBUTEFEED);

	public static final String CATEGORY_SPECIFIC_ATTRIBUTES_FILEUNPROCESSED_FOLDER = "/opt/stibo/integration/hotfolder/WayFairIncoming/Attribute/File_Unprocessed/";

	public static final String WAYFAIR_CATEGORY_ATTRIBUTE_HEADER = "wayfair.category.attributes.header";

	public static final String WAYFAIR_ATTRIBUTEFEED_DELIMITER = "wayfair.attributefeed.delimiter";

	public static final String delimiter=IntgSrvPropertiesReader.getProperty(WAYFAIR_ATTRIBUTEFEED_DELIMITER);
	
	public static final String headerString=IntgSrvPropertiesReader.getProperty(WAYFAIR_CATEGORY_ATTRIBUTE_HEADER);

	public static final String[] headers = headerString.split(delimiter,-1);

	public static final String WSITEMNO = "WSItemNo";

	public static final String ATTRIBUTE_GROUP_STAPLES = "AttributeGroupStaples";

	public static final String ATTRIBUTE_NAME_STAPLES = "AttributeNameStaples";

	public static final String ATTRIBUTE_VALUES_STAPLES = "AttributeValueStaples";

	public static final String ATTRIBUTE_GROUP_QUILL = "AttributeGroupQuill";

	public static final String ATTRIBUTE_NAME_QUILL = "AttributeNameQuill";

	public static final String ATTRIBUTE_VALUES_QUILL = "AttributeValueQuill";

	public static final String ATTRIBUTE_ID_REFERENCE_FILE_CURRENT_PATH = "/opt/stibo/SpringBatch/Reference/wayfairlookup/attributefeed/current";

	public static final String ATTRIBUTE_ID_REFERENCE_FILE_OLD_PATH = "/opt/stibo/SpringBatch/Reference/wayfairlookup/attributefeed/old";

	public static final String WAYFAIR_ATTRIBUTEFEED_FILEDONE = "/opt/stibo/integration/hotfolder/WayFairIncoming/Attribute/File_Done/";
	
	/**
	 * 
	 */
	public void attributeInboundProcessor(){

		File folder = new File(IntgSrvUtils.reformatFilePath(CATEGORY_SPECIFIC_ATTRIBUTES_FILEUNPROCESSED_FOLDER));
		File[] files = DatamigrationCommonUtil.sortFilesBasedOnFIFO(folder, ProductInboundScheduler.PUBLISH_ID);
		for(int i=0;i<files.length;i++){
			try{
			logger.info(new Date().toString()+" Processing file : "+files[i].getName());
			readIncomingFile(files[i]);
			}catch(Exception e){
				logger.error("Exception while processing file : "+files[i].getName()+" : "+e.getMessage());
				e.printStackTrace();
			}
		}
	}

	/**
	 * @return
	 */
	public Map<String, String> getAttributeIDsFromReferenceFile(){
		Map<String, String> attributeIDsMap = new HashMap<String, String>();
		File referenceFile = DatamigrationCommonUtil.getReferenceFile(ATTRIBUTE_ID_REFERENCE_FILE_CURRENT_PATH, ATTRIBUTE_ID_REFERENCE_FILE_OLD_PATH);

		FileReader fileReader;
		BufferedReader reader;
		String tempString;
		String[] values;
		if(referenceFile!=null){
			try {
				fileReader = new FileReader(referenceFile);
				reader = new BufferedReader(fileReader);

				while ((tempString = reader.readLine()) != null) {
					if(!tempString.equals(DatamigrationAppConstants.EMPTY_STR)){
						values= tempString.split(delimiter, -1);
						attributeIDsMap.put(values[0], values[1]);
					}
				}
				
				reader.close();
				
			} catch (FileNotFoundException e) {
				e.printStackTrace();
				logger.error("Exception while getting reference File : "+e.getMessage());
			} catch (IOException e) {
				logger.error("Exception while getting reference File : "+e.getMessage());
				e.printStackTrace();
			}

		}else{
			logger.error("Reference File to Attribute IDs from attributemetadata Feed not found.");
		}

		return attributeIDsMap;
	}

	/**
	 * @param referenceMap
	 * @param key
	 * @return
	 */
	public String getValueFromReferenceMap(Map<String, String> referenceMap, String key){
		
		for(String AttributeNames : referenceMap.keySet()){
			if(key.equalsIgnoreCase(AttributeNames)){
				return referenceMap.get(key);
			}
		}
		logger.error("Attribute ID not found in the reference file");
		return "";
	}
	
	/**
	 * @param file
	 * 
	 * reads and processes input file
	 */
	public void readIncomingFile(File file){
		FileReader fileReader;
		String tempString;
		int lineno=0;
		String[] values;
		List<Map<String,String>> quillCategorySpecAttributesList = new ArrayList<Map<String, String>>();
		List<Map<String,String>> staplesCategorySpecAttributesList = new ArrayList<Map<String, String>>();
		Map<String,String> mapContainingRecord;
		try {
			fileReader = new FileReader(file.getPath());
			BufferedReader br = new BufferedReader(fileReader);
			
			//parse file line by line
			while ((tempString = br.readLine()) != null) {
				if(!tempString.equals("")){

					if(lineno==0){
						//						headers=tempString.split(delimiter,-1);
					}else{
						values=tempString.split(delimiter,-1);
						mapContainingRecord=DatamigrationCommonUtil.getRecordAsMap(headers,values,logger);
						if(mapContainingRecord!=null){
							if(!((EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_GROUP_STAPLES))) && (EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_NAME_STAPLES))) && (EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_VALUES_STAPLES))))){
								staplesCategorySpecAttributesList.add(mapContainingRecord);
							}else if(!((EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_GROUP_QUILL))) && (EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_NAME_QUILL))) && (EMPTY_STR.equalsIgnoreCase(mapContainingRecord.get(ATTRIBUTE_VALUES_QUILL))))){
								quillCategorySpecAttributesList.add(mapContainingRecord);
							}
						}else{
							logger.error("Record omitted. Incorrect no of values :"+tempString);
							DatamigrationCommonUtil.appendWriterFile(file.getParentFile().getParentFile() + "/Report/Report_" + file.getName(), tempString
									+ "~Has incorrect number of Values in record :"+values.length);
						}
					}
					lineno++;
				}
			}
			br.close(); fileReader.close();

			//get attribute IDs from reference file
			logger.info("getting attribute IDs from reference file");
			Map<String, String> referenceMap = getAttributeIDsFromReferenceFile();
			
			//create step xml object
			STEPProductInformation stepPrdInfo = createSTEPProductInformationObject(staplesCategorySpecAttributesList,quillCategorySpecAttributesList,referenceMap);
			
			//marshall object
			File outputFile = DatamigrationCommonUtil.marshallObject(stepPrdInfo, file, DatamigrationAppConstants.WAYFAIR_ATTRIBUTE_FEED_OUTPUT_FOLDER, ProductInboundScheduler.PUBLISH_ID);
			
			//send file to sftp location
			logger.info("sending step xml to sftp location");
			DatamigrationCommonUtil.sendFile(outputFile, file,WAYFAIR_ATTRIBUTEFEED_FILEDONE , "14", true, ProductInboundScheduler.PUBLISH_ID);
			logger.info("file transfered successfully.");
			
		}catch (FileNotFoundException e) {
			logger.error("Exception while processing file : "+file.getName()+" : "+e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			logger.error("Exception while processing file : "+file.getName()+" : "+e.getMessage());
			e.printStackTrace();
		} catch (Exception e){
			logger.error("Exception while processing file : "+file.getName()+" : "+e.getMessage());
			e.printStackTrace();
		}
	}

	/**
	 * @param staplesCategorySpecAttributesList
	 * @param quillCategorySpecAttributesList
	 * @param referenceMap
	 * @return
	 */
	public STEPProductInformation createSTEPProductInformationObject(List<Map<String,String>> staplesCategorySpecAttributesList,List<Map<String,String>> quillCategorySpecAttributesList, Map<String, String> referenceMap){
		logger.info("creating Step xml");
		
		ObjectFactory objectFactory = new ObjectFactory();
		STEPProductInformation stepPrdInfo = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

//		add staples objects
		for(Map<String, String> staplesMap : staplesCategorySpecAttributesList){
			ProductType product = objectFactory.createProductType();
			product.setID(staplesMap.get(WSITEMNO));
			product.setParentID("WayFairItems");
			product.setUserTypeID("Item");
			product.setSelected(false);
			product.setReferenced(true);

			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();

			String key = staplesMap.get(ATTRIBUTE_GROUP_STAPLES)+REFERENCE_FILE_DELIMITER+staplesMap.get(ATTRIBUTE_NAME_STAPLES);
			String IDs = getValueFromReferenceMap(referenceMap,key);
			if(!IDs.equalsIgnoreCase(DatamigrationAppConstants.EMPTY_STR)){
				String[] referenceValues = IDs.split(REFERENCE_FILE_DELIMITER, -1); 
				if(referenceValues.length>1){
					value.setID(referenceValues[1]);
				}
			}
			value.setContent(staplesMap.get(ATTRIBUTE_NAME_STAPLES));
			
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

//		add quill objects
		for(Map<String, String> staplesMap : quillCategorySpecAttributesList){
			ProductType product = objectFactory.createProductType();
			product.setID(staplesMap.get(WSITEMNO));
			product.setParentID("WayFairItems");
			product.setUserTypeID("Item");
			product.setSelected(false);
			product.setReferenced(true);

			ValuesType values = objectFactory.createValuesType();
			ValueType value = objectFactory.createValueType();

			String key = staplesMap.get(ATTRIBUTE_GROUP_QUILL)+REFERENCE_FILE_DELIMITER+staplesMap.get(ATTRIBUTE_NAME_QUILL);
			String IDs = getValueFromReferenceMap(referenceMap,key);
			if(!IDs.equalsIgnoreCase(DatamigrationAppConstants.EMPTY_STR)){
				String[] referenceValues = IDs.split(REFERENCE_FILE_DELIMITER, -1); 
				if(referenceValues.length>1){
					value.setID(referenceValues[1]);
				}
			}
			value.setContent(staplesMap.get(ATTRIBUTE_NAME_QUILL));
			
			values.getValueOrMultiValueOrValueGroup().add(value);
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}
		
		stepPrdInfo.setProducts(products);
		stepPrdInfo.setExportTime(DatamigrationCommonUtil.getCurrentDateForSTEP()); // Current
		stepPrdInfo.setContextID(CONTEXT_ID_VALUE); // Hard coded value
		stepPrdInfo.setExportContext(EXPORT_CONTEXT_VALUE);// Hard coded value
		stepPrdInfo.setWorkspaceID(WORKSPACE_ID_VALUE);// Hard coded value
		logger.info("Step xml created");
		return stepPrdInfo;
	}
	
	public static void main(String[] args) {
				new CategorySpecificAttributeInboundProcessor().attributeInboundProcessor();

	}

}
