/**
 * -----------------------------------------------------------------------
 * STAPLES, INC
 * -----------------------------------------------------------------------
 * (C) Copyright 2007 Staples, Inc.          All rights reserved.
 *
 * NOTICE:  All information contained herein or attendant hereto is,
 *          and remains, the property of Staples Inc.  Many of the
 *          intellectual and technical concepts contained herein are
 *          proprietary to Staples Inc. Any dissemination of this
 *          information or reproduction of this material is strictly
 *          forbidden unless prior written permission is obtained
 *          from Staples Inc.
 * -----------------------------------------------------------------------
 */
/*
 * File name     :   ILocationLevelPushDownDAO
 * Creation Date :   July 18, 2015
 * @author        :  Sima Zaslavsky 
 * @version 1.0
 */
package com.staples.pim.delegate.locationlevel.dao;

import java.util.List;

import com.staples.pim.base.common.exception.IntgSrvBatchException;
import com.staples.pim.delegate.locationlevel.bean.StepLocationLevelPushDownData;


/**
 * Interface for Common Business related Data Access Objects.
 * Contains : The methods to be implemented in the corresponding implementation class.  
 */
public interface ILocationLevelPushDownDAO {
	
	/**
	 * The method invokes the stored procedure to update the location level attributes on Retail iSeries server
	 * @return List of  
	 * @throws IntgSrvBatchException 
	 */
	  
	@SuppressWarnings("rawtypes")
	public List locationLevelPushDownRetail(StepLocationLevelPushDownData inputTO);
	
	/**
	 * The method invokes the stored procedure to update the location level attributes on Nad iSeries server
	 * @return List of  
	 * @throws IntgSrvBatchException 
	 */
	  
	@SuppressWarnings("rawtypes")
	public List locationLevelPushDownScc(StepLocationLevelPushDownData inputTO);


}
