package com.staples.pim.delegate.wercs.steptowercs.retry.processor;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.staples.pcm.stepcontract.beans.MultiValueType;
import com.staples.pcm.stepcontract.beans.ObjectFactory;
import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.base.loader.IntgSrvPropertiesReader;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.wercs.databaseprocessor.DatabaseAccessor;
import com.staples.pim.delegate.wercs.databaseprocessor.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.processor.WERCSRestAPIProcessor;
import com.staples.pim.delegate.wercs.steptowercs.retry.runner.RunSchedulerWercsRetry;


public class WercsRegStatusRetryProcessor {

	public void processWercsRegStatusRetry(){
		
		List<MasterTableVO> masterTableVOList = getUpcsToRetry();
		if(masterTableVOList.size()>0){
			Map<String,MasterTableVO> masterTableVOMap = new WERCSRestAPIProcessor().processWercsAPIRequests(masterTableVOList);
			processResponsesFromWercs(masterTableVOMap);
		}
	}
	
	public List<MasterTableVO> getUpcsToRetry(){
		DatabaseAccessor dbAccess = (DatabaseAccessor)RunSchedulerWercsRetry.context.getBean("databaseAccess");
		List<MasterTableVO> masterTableVOList = dbAccess.getWercsRetryUPCs();
		return masterTableVOList;
	}
	
	public void processResponsesFromWercs(Map<String,MasterTableVO> masterTableVOs){
		
		//xmls to be sent to step
		Map<String,MasterTableVO> itemsToSTEP = new HashMap<String,MasterTableVO>();
		//rejected xmls to be sent to step
		List<MasterTableVO> rejectedItems = new ArrayList<MasterTableVO>();
		
		for(String upcNo : masterTableVOs.keySet()){
			
			MasterTableVO masterTableVO = masterTableVOs.get(upcNo);
			int registration_Status = masterTableVO.getRegistrationStatus();
			
			if(registration_Status!=-1){
				//if status = 1 send xml to step
				if(registration_Status==1){
					itemsToSTEP.put(upcNo, masterTableVO);
				}else{
					
					//current time
					Calendar currentCalendarTime = Calendar.getInstance();
					//created time
					Calendar createdCalendarTime = Calendar.getInstance();
					createdCalendarTime.setTimeInMillis(masterTableVO.getCreatedDate().getTime());
					int rejectionTimespan = Integer.parseInt(IntgSrvPropertiesReader.getProperty("WERCS_TIMETO_REJECT_ITEM"));
					createdCalendarTime.set(createdCalendarTime.HOUR_OF_DAY, createdCalendarTime.get(createdCalendarTime.HOUR_OF_DAY)+rejectionTimespan);
					
					if(currentCalendarTime.after(createdCalendarTime)){
						//means time span exceeded
						rejectedItems.add(masterTableVO);
					}else{
						
						//previous registration status set as soon as row retrieved from DB
						if(registration_Status!=masterTableVO.getPreviousRegistrationStatus()){
							itemsToSTEP.put(upcNo, masterTableVO);
						}else{
							System.out.println("status unchanged for upc:"+upcNo);
						}
					}
				}
			}
		}
		
		//send status to step
		if(itemsToSTEP.size()>0){
			STEPProductInformation stepProdInfo = getSTEPProductInformationObjectForResponses(itemsToSTEP);
			File file = new File("C:/opt/stibo/SpringBatch/outputs/WERCSOut/WercsToStep/"+new Date().getTime()+".xml");
			File outputFile=DatamigrationCommonUtil.marshallObject(stepProdInfo, file, "WERCS_STEP_OUTPUT_FOLDER_RETRY", "WERCSToSTEP");
			DatamigrationCommonUtil.sendWercrsResponseFile(outputFile, "WercsResponseXML", "");
		}else{
			System.out.println("No item with status 1 and no item with status change.");
		}
		
		//Reject xmls
		if(rejectedItems.size()>0){
			STEPProductInformation stepProdInfo = getSTEPProductInformationForRejected(rejectedItems);
			File file = new File("C:/opt/stibo/SpringBatch/outputs/WERCSOut/WercsToStep/"+"Rejected_"+new Date().getTime()+".xml");
			File outputFile=DatamigrationCommonUtil.marshallObject(stepProdInfo, file, "WERCS_STEP_OUTPUT_FOLDER_RETRY", "WERCSToSTEP");
			DatamigrationCommonUtil.sendWercrsResponseFile(outputFile, "WercsResponseXML", "");
		}else{
			System.out.println("No item is rejected.");
		}
	}
	
	public STEPProductInformation getSTEPProductInformationForRejected(List<MasterTableVO> rejectedItems){
		ObjectFactory objectFactory = new ObjectFactory();
		STEPProductInformation stepProductInformation = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

		for(MasterTableVO masterTableVO : rejectedItems){
			
			ProductType product = objectFactory.createProductType();
			product.setID(masterTableVO.getStepid());
			product.setUserTypeID("Item");
			product.setParentID("WERCSItemsRejected");
			
			ValuesType values = objectFactory.createValuesType();

			MultiValueType multiValue = objectFactory.createMultiValueType();
			multiValue.setAttributeID("A0080");
			
			ValueType upcValue = objectFactory.createValueType();
			upcValue.setContent(masterTableVO.getUPCNo());
			
			multiValue.getValueOrValueGroup().add(upcValue);
			values.getValueOrMultiValueOrValueGroup().add(multiValue);

			
			ValueType statusValue = objectFactory.createValueType();
			statusValue.setAttributeID("A2034");
			statusValue.setContent(DatamigrationCommonUtil.getValuesFromLOV("RegistrationStatus",Integer.toString(masterTableVO.getRegistrationStatus()), false));
			values.getValueOrMultiValueOrValueGroup().add(statusValue);

			ValueType modelNOValue = objectFactory.createValueType();
			modelNOValue.setAttributeID("A0013_RET");
			modelNOValue.setContent(masterTableVO.getModelno());
			values.getValueOrMultiValueOrValueGroup().add(modelNOValue);
			
			ValueType rejectedStatusValue = objectFactory.createValueType();
			rejectedStatusValue.setAttributeID("A2028");
			rejectedStatusValue.setContent("40:Rejected due to Supplier Non-compliance");
			values.getValueOrMultiValueOrValueGroup().add(rejectedStatusValue);
//			A2028
			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}
		
		stepProductInformation.setProducts(products);
		return stepProductInformation;
	}
	
	public STEPProductInformation getSTEPProductInformationObjectForResponses(Map<String,MasterTableVO> masterTableVOMap){

		ObjectFactory objectFactory = new ObjectFactory();
		STEPProductInformation stepProductInformation = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

		for(String upcNO : masterTableVOMap.keySet()){
			String upcNumber = upcNO;
			MasterTableVO masterTableVO = masterTableVOMap.get(upcNumber);

			String registrationStatus = Integer.toString(masterTableVO.getRegistrationStatus());

			ProductType product = objectFactory.createProductType();
			product.setID(masterTableVO.getStepid());
			product.setUserTypeID("Item");
			
			ValuesType values = objectFactory.createValuesType();

			ValueType upcValue = objectFactory.createValueType();
			upcValue.setAttributeID("A0080");
			upcValue.setContent(upcNumber);
			values.getValueOrMultiValueOrValueGroup().add(upcValue);

			ValueType statusValue = objectFactory.createValueType();
			statusValue.setAttributeID("A2034");
			statusValue.setContent(DatamigrationCommonUtil.getValuesFromLOV("RegistrationStatus",registrationStatus , false));
			values.getValueOrMultiValueOrValueGroup().add(statusValue);

			product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
			products.getProduct().add(product);
		}

		stepProductInformation.setProducts(products);
		return stepProductInformation;
	}
	
}
