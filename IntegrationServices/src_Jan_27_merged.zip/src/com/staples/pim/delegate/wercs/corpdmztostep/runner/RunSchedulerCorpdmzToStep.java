package com.staples.pim.delegate.wercs.corpdmztostep.runner;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;


public class RunSchedulerCorpdmzToStep extends RunScheduler{

	@Override
	public void run() {

		// TODO Auto-generated method stub
		
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		// TODO Auto-generated method stub
		return null;
	}

}
