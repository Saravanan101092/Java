package com.staples.pim.delegate.wercs.steptowercs.processor;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.staples.pcm.stepcontract.beans.ObjectFactory;
import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.wercs.databaseprocessor.DatabaseAccessor;
import com.staples.pim.delegate.wercs.databaseprocessor.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.bean.ResponseClass;
import com.staples.pim.delegate.wercs.steptowercs.bean.Upc;
import com.staples.pim.delegate.wercs.steptowercs.bean.Upclist;
import com.staples.pim.delegate.wercs.steptowercs.retry.runner.RunSchedulerWercsRetry;
import com.staples.pim.delegate.wercs.steptowercs.runner.RunSchedulerStepToWercs;

public class WERCSRestAPIProcessor {

	public STEPProductInformation processSTEPWercsRequest(List<MasterTableVO> masterTableVOs){
		Map<String,MasterTableVO> masterTableVOMap = processWercsAPIRequests(masterTableVOs);
		if(masterTableVOMap!=null){
			return getSTEPProductInformationObjectForResponses(masterTableVOMap);
		}else{
			return null;
		}
	}

	public Map<String,MasterTableVO> processWercsAPIRequests(List<MasterTableVO> masterTableVOs){

		System.out.println("processWercsAPIRequests");

		STEPProductInformation stepProductInformation=null;
		Upclist upcList = new Upclist();
		List<Upc> responseList= new ArrayList<Upc>();
		Set<String> upcsUnique = new HashSet<String>();
		Map<String,MasterTableVO> masterTableVOMap = new HashMap<String,MasterTableVO>();
		for(MasterTableVO masterTableVO : masterTableVOs){

			Upc upc = new Upc();
			String upcNo = masterTableVO.getUPCNo();
			masterTableVOMap.put(upcNo, masterTableVO);
			if(upcNo != null){
				upcsUnique.add(upcNo);
				upc.setGtin(upcNo);
				upcList.getUpc().add(upc);
			}else{
				System.out.println("UPC no not found in the xml.");
			}

			if(upcList.getUpc().size()>999){
				System.out.println("unique upcs size:"+upcsUnique.size());
				List<Upc> responses = hitRestAPI(upcList);
				if(responses!=null){
					responseList.addAll(responses);
				}
				upcList.getUpc().clear();
			}
		}
		if(upcList.getUpc().size()>0){
			System.out.println("unique upcs size:"+upcsUnique.size());
			List<Upc> finalResponses = hitRestAPI(upcList);

			if(finalResponses!=null){
				responseList.addAll(finalResponses);
			}
		}
		if(responseList.size()>0){
			//			stepProductInformation = getSTEPProductInformationObjectForResponses(responseList,masterTableVOMap);
			masterTableVOMap=setRegistrationStatuses(responseList,masterTableVOMap);
		}else{
			System.out.println("ResponseList is empty!");
			return null;
		}

		return masterTableVOMap;
	}

	public Map<String,MasterTableVO> setRegistrationStatuses(List<Upc> upcsResponseList,Map<String,MasterTableVO> masterTableMap){

		for(Upc upc :upcsResponseList){

			MasterTableVO masterTableVO = masterTableMap.get(upc.getGtin());
			
			//update response in db
			DatabaseAccessor dbAccess;
			if(RunSchedulerStepToWercs.context!=null){
				dbAccess = (DatabaseAccessor)RunSchedulerStepToWercs.context.getBean("databaseAccess");
			}else{
				dbAccess = (DatabaseAccessor)RunSchedulerWercsRetry.context.getBean("databaseAccess");
			}
			dbAccess.registrationStatusUpdate(masterTableVO.getUPCNo(),masterTableVO.getPipid(),upc.getStatus().intValue());
			
			masterTableVO.setRegistrationStatus(upc.getStatus().intValue());
		}

		return masterTableMap;
	}
	public STEPProductInformation getSTEPProductInformationObjectForResponses(Map<String,MasterTableVO> masterTableVOMap){

		ObjectFactory objectFactory = new ObjectFactory();
		STEPProductInformation stepProductInformation = objectFactory.createSTEPProductInformation();
		ProductsType products = objectFactory.createProductsType();

		for(String upcNO : masterTableVOMap.keySet()){
			String upcNumber = upcNO;
			MasterTableVO masterTableVO = masterTableVOMap.get(upcNumber);
			String pipID = masterTableVO.getPipid();

			if(masterTableVO.getRegistrationStatus() != -1){
				String registrationStatus = Integer.toString(masterTableVO.getRegistrationStatus());
				if(!"1".equalsIgnoreCase(registrationStatus) && ("70:SupplierExemptFromWERCS".equalsIgnoreCase(masterTableVO.getWercsTrigger()))){

					DatabaseAccessor dbAccess = (DatabaseAccessor)RunSchedulerStepToWercs.context.getBean("databaseAccess");
					dbAccess.auditTableInsert(masterTableVO.getUPCNo(),masterTableVO.getPipid(),506);
					System.out.println("Send Exempt Mail:"+masterTableVO.getUPCNo()+" updated in DB Audit table");

					//send mail with XL sheet
					new SendExemptMailSender().createAndSendExemptMail(upcNumber, pipID, masterTableVO.getSupplierName(),masterTableVO.getToner_Wholesaler());
				}


				ProductType product = objectFactory.createProductType();
				product.setID(masterTableVO.getStepid());
				product.setUserTypeID("Item");

				ValuesType values = objectFactory.createValuesType();

				ValueType upcValue = objectFactory.createValueType();
				upcValue.setAttributeID("A0080");
				upcValue.setContent(upcNumber);
				values.getValueOrMultiValueOrValueGroup().add(upcValue);

				ValueType statusValue = objectFactory.createValueType();
				statusValue.setAttributeID("A2034");
				statusValue.setContent(DatamigrationCommonUtil.getValuesFromLOV("RegistrationStatus",registrationStatus , false));
				values.getValueOrMultiValueOrValueGroup().add(statusValue);

				product.getProductOrSequenceProductOrSuppressedProductCrossReference().add(values);
				products.getProduct().add(product);
			}
		}

		stepProductInformation.setProducts(products);
		return stepProductInformation;
	}

	public String getUpcNo(STEPProductInformation stepProductInfo){

		ProductsType products = stepProductInfo.getProducts();
		for(ProductType product : products.getProduct()){
			List<Object> valuesTypeObjects = product.getProductOrSequenceProductOrSuppressedProductCrossReference();

			for(Object valuesObject : valuesTypeObjects){
				if("ValuesType".equalsIgnoreCase(valuesObject.getClass().getSimpleName())){
					ValuesType values = (ValuesType)valuesObject;
					List<Object> valueObjects = values.getValueOrMultiValueOrValueGroup();
					for(Object valueObject : valueObjects){
						if("ValueType".equalsIgnoreCase(valueObject.getClass().getSimpleName())){
							ValueType value = (ValueType)valueObject;
							if("A0080".equalsIgnoreCase(value.getAttributeID())){
								return value.getContent();
							}
						}
					}
				}
			}
		}

		return null;
	}

	public List<Upc> hitRestAPI(Upclist upclist){

		System.out.println("Request UPC size:"+upclist.getUpc().size());
		Upclist responses=null;
		try{
			RestTemplate restTemplate = new RestTemplate();


			MultiValueMap<String, String> headers = new LinkedMultiValueMap<String, String>();
			headers.add("UserName","StaplesTest");
			headers.add("Password","StaplesTest20!6");
			headers.add("Content-Type", "application/json");

			ResponseClass response= restTemplate.postForObject("https://lookup.wercsmart.com/RequestedUPCServiceTest/api/ClientAPI/Login",headers, ResponseClass.class );

			System.out.println(response.getsErrorMessage());
			System.out.println("Token from server:"+response.getsToken());
			System.out.println("bError flag:"+response.getBError());

			if(!response.getBError()){
				HttpHeaders httpHeader = new HttpHeaders();
				httpHeader.setContentType(MediaType.TEXT_XML);

				JAXBContext jaxbContext = JAXBContext.newInstance(Upclist.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

				StringWriter strWriter = new StringWriter();

				jaxbMarshaller.marshal(upclist, strWriter);
				System.out.println(strWriter.toString());
				HttpEntity<String> entity = new HttpEntity<String>(strWriter.toString(), httpHeader);

				String urlForUPC="https://lookup.wercsmart.com/RequestedUPCServiceTest/api/ClientAPI/ProcessRetailerUPCList?client=CE93F6B9-84D2-4BCF-B286-688C112783A1&token="+response.getsToken();
				restTemplate.getMessageConverters().add(new StringHttpMessageConverter());

				ResponseEntity<Upclist> resultString = restTemplate.exchange(urlForUPC, HttpMethod.POST, entity, Upclist.class);
				responses = resultString.getBody();
				return responses.getUpc();
			}else{
				System.out.println("Authentication error!");
			}
		}catch(HttpClientErrorException httpclientException){
			System.out.println(new Date().toString());
			System.out.println("HttpClientErrorException caught !! "+httpclientException.getMessage());
		}catch(Exception e){
			System.out.println(new Date().toString());
			System.out.println("Exception caught:"+e.getMessage());
			e.printStackTrace();
		}

		return null;
	}

	public static void main(String[] args){
		Upclist upclist = new Upclist();
		Upc upc1 = new Upc();
		upc1.setGtin("686875462398");
		upclist.getUpc().add(upc1);
		Upc upc2 = new Upc();
		upc2.setGtin("686875462399");
		upclist.getUpc().add(upc2);
		new WERCSRestAPIProcessor().hitRestAPI(upclist);
	}
}
