package com.staples.pim.delegate.wercs.steptowercs.processor;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.SkipListener;
import org.springframework.batch.item.file.MultiResourceItemReader;
import org.springframework.core.io.Resource;

import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.base.common.listenerandrunner.BatchJobListener;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.wercs.databaseprocessor.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.runner.RunSchedulerStepToWercs;



public class WercsItemListener extends BatchJobListener implements ItemReadListener<STEPProductInformation>,ItemProcessListener<STEPProductInformation, MasterTableVO>,SkipListener<STEPProductInformation, Throwable>{

	public static final String[] mandatoryAttributes = {"A2028","WERCS_Out_Trigger","A0080","A0405","A0013","A0282","SupplierHierID","A0009","STEP_ID"};
	public static List<File> succeededFiles;
	
	//	ItemProcessListener<STEPProductInformation, Throwable>,
	@Override
	public void afterJob(JobExecution jobExecution) {
		System.out.println("listener :after job");
		String fileDoneFolder = IntgSrvUtils.reformatFilePath("/opt/stibo/integration/hotfolder/WERCSIncoming/STEPRegistrationRequest/File_Done/");
		
		for(File file:succeededFiles){
			File destinationFile = new File(fileDoneFolder+file.getName());
			try {
				Files.move(file.toPath(), destinationFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
			} catch (IOException e) {
				System.out.println("Error while copying file to File_Done folder."+e.getMessage());
				e.printStackTrace();
			}
		}
	}

	@Override
	public void beforeJob(JobExecution jobExecution) {
		System.out.println("listener :before job");
		succeededFiles = new ArrayList<File>();
	}

	@Override
	public void afterProcess(STEPProductInformation arg0, MasterTableVO arg1) {

		System.out.println("listener: afterprocess");
	}


	@Override
	public void beforeProcess(STEPProductInformation arg0) {

		System.out.println("listener: beforerprocess");
	}


	@Override
	public void onProcessError(STEPProductInformation arg0, Exception arg1) {

		System.out.println("listener: onprocesserrorprocess");
	}

	@Override
	public void onSkipInProcess(STEPProductInformation arg0, Throwable arg1) {

		System.out.println("listener: onskiptinprocess : "+arg0.getProducts().getProduct().get(0).getID());
	}

	@Override
	public void onSkipInRead(Throwable arg0) {

		System.out.println("listener: onskipinread");
	}

	@Override
	public void onSkipInWrite(Throwable arg0, Throwable arg1) {

		System.out.println("listener: onskipinwrite");
	}

	@Override
	public void afterRead(STEPProductInformation stepProductInformation) {
		System.out.println("listener: afterRead");
		MultiResourceItemReader multiResourceItemReader = 	(MultiResourceItemReader)RunSchedulerStepToWercs.context.getBean("multiResourceReader");
		Resource currentResource = multiResourceItemReader.getCurrentResource();
		//validate input xml. check if all mandatory values are present
		if(!containsAllMandatoryValues(stepProductInformation)){
			
			try {
				File badFile = currentResource.getFile();
				File fileBadFolder = new File(badFile.getParentFile().getParentFile().getAbsolutePath()+File.separator+"File_Bad");
				if(!fileBadFolder.exists()){
					fileBadFolder.mkdirs();
				}
				File destination = new File(fileBadFolder.getAbsolutePath()+File.separator+badFile.getName());
				
				Files.move(badFile.toPath(), destination.toPath(), StandardCopyOption.REPLACE_EXISTING);

			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			try {
				File succeededFile = currentResource.getFile();
				succeededFiles.add(succeededFile);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void beforeRead() {
		System.out.println("listener: beforeRead");
		
	}

	@Override
	public void onReadError(Exception arg0) {
		System.out.println("listener: onreadError");
		
	}
	
	public boolean containsAllMandatoryValues(STEPProductInformation stepProductInformation){
		Map<String,String> valuesInXml = new HashMap<String,String>();

		ProductsType products = stepProductInformation.getProducts();
		List<ProductType> productList = products.getProduct();
		for(ProductType product:productList){
			valuesInXml.put("STEP_ID", product.getID());
			for(Object productObj : product.getProductOrSequenceProductOrSuppressedProductCrossReference()){
				if("ValuesType".equalsIgnoreCase(productObj.getClass().getSimpleName())){
					ValuesType values = (ValuesType) productObj;
					for(Object valueObj : values.getValueOrMultiValueOrValueGroup()){
						if("ValueType".equalsIgnoreCase(valueObj.getClass().getSimpleName())){
							ValueType value = (ValueType) valueObj;
							valuesInXml.put(value.getAttributeID(), value.getContent());
						}

					}
				}
			}
		}
		
		for(String mandatoryAttribute:mandatoryAttributes){
			if(IntgSrvUtils.isNullOrEmpty(valuesInXml.get(mandatoryAttribute))){
				return false;
			}
		}
		return true;
	}
}
