package com.staples.pim.delegate.wercs.steptowercs.processor;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.batch.core.ItemProcessListener;
import org.springframework.batch.item.ItemProcessor;

import com.staples.pcm.stepcontract.beans.ProductType;
import com.staples.pcm.stepcontract.beans.ProductsType;
import com.staples.pcm.stepcontract.beans.STEPProductInformation;
import com.staples.pcm.stepcontract.beans.ValueType;
import com.staples.pcm.stepcontract.beans.ValuesType;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.datamigration.utils.DatamigrationCommonUtil;
import com.staples.pim.delegate.wercs.databaseprocessor.DatabaseAccessor;
import com.staples.pim.delegate.wercs.databaseprocessor.MasterTableVO;
import com.staples.pim.delegate.wercs.steptowercs.runner.RunSchedulerStepToWercs;



public class StepToWercsIntgProcessor implements ItemProcessor<STEPProductInformation, MasterTableVO>{

	public DatabaseAccessor databaseAccessor;
	
	public static final String[] mandatoryAttributes = {"A2028","WERCS_Out_Trigger","A0080","A0405","A0013_RET","A0282","SupplierHierID","A0009","A0621","STEP_ID"};
	public DatabaseAccessor getDatabaseAccessor() {
	
		return databaseAccessor;
	}

	public void setDatabaseAccessor(DatabaseAccessor databaseAccessor) {
	
		this.databaseAccessor = databaseAccessor;
	}

	@Override
	public MasterTableVO process(STEPProductInformation stepProductInformation) throws Exception {
		
		System.out.println("WERCS processor.");
		
		MasterTableVO masterTableVO = getMasterTableVO(stepProductInformation);
		if(masterTableVO!=null){
			//2. Make an entry in the master table for the upc
			String upc = masterTableVO.getUPCNo();
			masterTableVO.setUPCNo(DatamigrationCommonUtil.addLeadingCharacter(upc, 14, '0'));
			databaseAccessor.masterTableInsertUpdate(masterTableVO);
			
			if("Rules Tripped Mail".equalsIgnoreCase(masterTableVO.getWercsTrigger())){
				DatabaseAccessor dbAccess = (DatabaseAccessor)RunSchedulerStepToWercs.context.getBean("databaseAccess");
				dbAccess.auditTableInsert(masterTableVO.getUPCNo(),masterTableVO.getPipid(),505);
				System.out.println("RulesTripped:"+masterTableVO.getUPCNo()+" updated in DB");
				return null;
			}
			return masterTableVO;
		}else{
			return null;
		}
	}
	
	public MasterTableVO getMasterTableVO(STEPProductInformation stepProductInformation){
		
		MasterTableVO mastertableVO = new MasterTableVO();
		Map<String,String> valuesInXml = new HashMap<String,String>();

		ProductsType products = stepProductInformation.getProducts();
		List<ProductType> productList = products.getProduct();
		for(ProductType product:productList){
			valuesInXml.put("STEP_ID", product.getID());
			for(Object productObj : product.getProductOrSequenceProductOrSuppressedProductCrossReference()){
				if("ValuesType".equalsIgnoreCase(productObj.getClass().getSimpleName())){
					ValuesType values = (ValuesType) productObj;
					for(Object valueObj : values.getValueOrMultiValueOrValueGroup()){
						if("ValueType".equalsIgnoreCase(valueObj.getClass().getSimpleName())){
							ValueType value = (ValueType) valueObj;
							valuesInXml.put(value.getAttributeID(), value.getContent());
						}

					}
				}
			}
		}
		
			mastertableVO.setUPCNo(valuesInXml.get("A0080"));
			mastertableVO.setWercsID(valuesInXml.get("A0621"));//hardcoded//FIXME
			mastertableVO.setStepid(valuesInXml.get("STEP_ID"));
			mastertableVO.setPipid(valuesInXml.get("A0405"));
			mastertableVO.setSkuno(valuesInXml.get("A1363"));//hardcoded
			mastertableVO.setModelno(valuesInXml.get("A0013"));
			mastertableVO.setSupplierName(valuesInXml.get("SupplierHierID"));
			mastertableVO.setRequestorName(valuesInXml.get("A0282"));
			mastertableVO.setItemdesc("fetdhdf");//hardcoded//FIXME
			mastertableVO.setSupplierMail("sdfghe");//hardcoded//FIXME
			mastertableVO.setPsmail("dummy");//hardcoded//FIXME
			mastertableVO.setMerchantMail("dummy");//hardcoded//FIXME
			mastertableVO.setTranstype(valuesInXml.get("A0009"));
			mastertableVO.setWercsTrigger(valuesInXml.get("WERCS_Out_Trigger"));
			mastertableVO.setRegulatoryStatus("0");//HARDCODED
			mastertableVO.setRegistrationStatus(-1);
			mastertableVO.setToner_Wholesaler(valuesInXml.get("A2035"));
		return mastertableVO;
	}
	

}
