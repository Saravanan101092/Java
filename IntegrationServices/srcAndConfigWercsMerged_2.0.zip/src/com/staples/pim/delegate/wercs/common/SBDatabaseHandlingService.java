package com.staples.pim.delegate.wercs.common;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.staples.pim.base.common.logging.IntgSrvLogger;
import com.staples.pim.base.util.IntgSrvAppConstants;
import com.staples.pim.base.util.IntgSrvUtils;
import com.staples.pim.delegate.wercs.model.MasterTableVO;

import oracle.jdbc.pool.OracleDataSource;
public class SBDatabaseHandlingService {

	public static String			infoLogString;
	protected IntgSrvLogger			traceLogger											= IntgSrvLogger.getInstance(IntgSrvAppConstants.FREEFORM_TRACE_LOGGER);
	protected String 				clazzname 											= this.getClass().getName();
	protected IntgSrvLogger			ehfLogger 											= IntgSrvLogger.getInstance(IntgSrvAppConstants.EHF_LOGGER);

	
	public OracleDataSource datasource;
	public final String masterTableInsertUpdateProcedure = "{call wercs_mastertable_insertupdate(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
	public final String registrationStatusUpdateProcedure = "{call WERCS_REGSTATUS_UPDATE(?,?,?)}";
	public final String wercsStatusAuditTableInsertProcedure = "{call wercs_status_audit_insert(?,?,?)}";
	public final String wercsRetryUPCsQuery = "select upc, pip_id, transaction_type, created_date, registration_status, wercs_out_trigger, regulatory_data_status, step_id, model_number from wercs_status_master where registration_status <> 1 and wercs_out_trigger = 'Get Status' and regulatory_data_status = '0'";
	
	public OracleDataSource getDatasource() {
	
		return datasource;
	}

	
	public void setDatasource(OracleDataSource datasource) {
	
		this.datasource = datasource;
	}
	
	public void masterTableInsertUpdate(MasterTableVO masterTableRow){
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;

		try {
			dbConnection = datasource.getConnection();
			if(dbConnection!=null){
				callableStatement = dbConnection.prepareCall(masterTableInsertUpdateProcedure);

				callableStatement.setString(1, masterTableRow.getUPCNo());
				callableStatement.setString(2, masterTableRow.getWercsID());
				callableStatement.setString(3, masterTableRow.getPipid());
				callableStatement.setString(4, masterTableRow.getSkuno());
				callableStatement.setString(5, masterTableRow.getStepid());
				callableStatement.setString(6, masterTableRow.getModelno());
				callableStatement.setString(7, masterTableRow.getItemdesc());
				callableStatement.setString(8, masterTableRow.getSupplierName());
				callableStatement.setString(9, masterTableRow.getRequestorName());
				callableStatement.setString(10, masterTableRow.getSupplierMail());
				callableStatement.setString(11, masterTableRow.getPsmail());
				callableStatement.setString(12, masterTableRow.getMerchantMail());
				callableStatement.setString(13, masterTableRow.getTranstype());
				callableStatement.setInt(14, masterTableRow.getRegistrationStatus());
				callableStatement.setString(15, masterTableRow.getWercsTrigger());
				callableStatement.setString(16, masterTableRow.getRegulatoryStatus());
				
				// execute getDBUSERByUserId store procedure
				int result = callableStatement.executeUpdate();

				if(result == 1)
				{
					infoLogString = "Procedure executed without exceptions. Inserted values into database. ";
					traceLogger.info(clazzname, "run", infoLogString);
					ehfLogger.info(infoLogString);
					IntgSrvUtils.printConsole(infoLogString);
				}
			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		} finally {

			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		
	}
	
	public void registrationStatusUpdate(String upcNo, String pipID, int registrationStatus){
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;

		try {
			dbConnection = datasource.getConnection();
			if(dbConnection!=null){
				callableStatement = dbConnection.prepareCall(registrationStatusUpdateProcedure);

				callableStatement.setString(1, upcNo);
				callableStatement.setInt(2, registrationStatus);
				callableStatement.setString(3, pipID);
				
				// execute getDBUSERByUserId store procedure
				int result = callableStatement.executeUpdate();

				System.out.println("Procedure executed without exceptions. Result="+result);
			}

		} catch (SQLException e) {

			System.out.println(e.getMessage() +"sdfs");

		} finally {

			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}
	
public void auditTableInsert(String upcNo, String pipID, int statusno){
		
		Connection dbConnection = null;
		CallableStatement callableStatement = null;

		try {
			dbConnection = datasource.getConnection();
			if(dbConnection!=null){
				callableStatement = dbConnection.prepareCall(wercsStatusAuditTableInsertProcedure);

				callableStatement.setString(1, upcNo);
				callableStatement.setInt(3, statusno);
				callableStatement.setString(2, pipID);
				
				// execute getDBUSERByUserId store procedure
				int result = callableStatement.executeUpdate();

				System.out.println("Procedure executed without exceptions.Result="+result);
			}

		} catch (SQLException e) {

			System.out.println(e.getMessage());

		} finally {

			if (callableStatement != null) {
				try {
					callableStatement.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

			if (dbConnection != null) {
				try {
					dbConnection.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
	}
	
public List<MasterTableVO> getWercsRetryUPCs(){
	
	Connection dbConnection = null;
	Statement statement = null;
	List<MasterTableVO> masterTableVOList = new ArrayList<MasterTableVO>();
	try {
		dbConnection = datasource.getConnection();
		if(dbConnection!=null){
			statement = dbConnection.createStatement();
			
			// execute getDBUSERByUserId store procedure
			ResultSet resultSet = statement.executeQuery(wercsRetryUPCsQuery);
			
				while(resultSet.next()){
					
					MasterTableVO masterTableVO = new MasterTableVO();
					masterTableVO.setUPCNo(resultSet.getString("upc"));
					masterTableVO.setPipid(resultSet.getString("pip_id"));
					masterTableVO.setTranstype(resultSet.getString("transaction_type"));
					masterTableVO.setCreatedDate(resultSet.getTimestamp("created_date"));
					masterTableVO.setPreviousRegistrationStatus(resultSet.getInt("registration_status"));
					masterTableVO.setStepid(resultSet.getString("step_id"));
					masterTableVO.setModelno(resultSet.getString("model_number"));
					masterTableVOList.add(masterTableVO);
				}
			System.out.println("Query executed without exceptions.");
		}

	} catch (SQLException e) {

		System.out.println(e.getMessage());

	} finally {

		if (statement != null) {
			try {
				statement.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (dbConnection != null) {
			try {
				dbConnection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
	
	return masterTableVOList;
}

	public static void main(String[] args){
		
		ApplicationContext context = new FileSystemXmlApplicationContext("file:C:\\integrationservicesworkspace\\IntegrationServices\\configurations\\job-StepToWercs.xml");
		
		SBDatabaseHandlingService dbaccess = (SBDatabaseHandlingService) context.getBean("databaseAccess");
		dbaccess.registrationStatusUpdate("10","34",2);
	}
}
