package com.staples.pim.delegate.wercs.steptowercs.processor;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.staples.pim.base.util.EmailUtil;
import com.staples.pim.base.util.IntgSrvUtils;


public class SendExemptMailSender {
	
	public String templateXLFileToner = IntgSrvUtils.reformatFilePath("/opt/stibo/SpringBatch/Reference/wercs/Toner_Template.xlsx");
	public String templateXLFileWholeSaler = IntgSrvUtils.reformatFilePath("/opt/stibo/SpringBatch/Reference/wercs/Wholesalers_Template.xlsx");
	public String outputFilepath = IntgSrvUtils.reformatFilePath("C:/opt/stibo/SpringBatch/outputs/WERCSOut/WercsToStep/excel/");
	public String sendExemptMailSubject = "SEND EXEMPT MAIL SUBJECT";
	
	
	public void createAndSendExemptMail(String upc, String pipID, String supplierID,String toner_wholesaler){
		
		File file = createXLDocument(upc,pipID,toner_wholesaler);
		//getSuppliermailID //FIXME
		sendExcelFile(file,"priyanka.venkat@staples.com");
	}
	
	public File createXLDocument(String upc,String pipID,String toner_wholesaler){
		FileInputStream fsIP;
		File outputFile = null;
		try {
			
			if("Toner".equalsIgnoreCase(toner_wholesaler)){
				fsIP = new FileInputStream(new File(templateXLFileToner));
			}else{
				fsIP = new FileInputStream(new File(templateXLFileWholeSaler));
			}
		// Read the spreadsheet that needs to be updated
		XSSFWorkbook wb = new XSSFWorkbook(fsIP);
		// Access the workbook
		XSSFSheet worksheet = wb.getSheetAt(0);
		// Access the worksheet, so that we can update / modify it.
		worksheet.getRow(1).getCell(0).setCellValue(pipID);;
		// Access the second cell in second row to update the value
		worksheet.getRow(1).getCell(2).setCellValue(upc);
		// Get current cell value value and overwrite the value
		fsIP.close(); // Close the InputStream
		outputFile = new File(outputFilepath+"Exempt"+new Date().getTime()+".xlsx");
		FileOutputStream output_file_stream = new FileOutputStream(outputFile);
		// Open FileOutputStream to write updates
		wb.write(output_file_stream); // write changes
		output_file_stream.close(); // close the stream
		
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return outputFile;
	} 
	
	public void sendExcelFile(File file,String supplierMail){
		
		EmailUtil emailUtil = new EmailUtil();
		emailUtil.sendEmail(sendExemptMailSubject, "THIS IS MESSAGE BODY!", supplierMail, file);
	}
	
	public static void main(String[] args){
//		new SendExemptMailSender().createXLDocument("asdf", "65456");
	}
}
