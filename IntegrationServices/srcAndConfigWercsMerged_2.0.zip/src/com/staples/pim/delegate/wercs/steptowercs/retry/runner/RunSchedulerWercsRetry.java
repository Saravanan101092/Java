package com.staples.pim.delegate.wercs.steptowercs.retry.runner;

import java.util.Date;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import com.staples.pim.base.common.bean.StepTransmitterBean;
import com.staples.pim.base.common.listenerandrunner.RunScheduler;
import com.staples.pim.delegate.wercs.steptowercs.retry.processor.WercsRegStatusRetryProcessor;


public class RunSchedulerWercsRetry  extends RunScheduler {

	public static ApplicationContext context;
	@Override
	public void run() {

		System.out.println("Triggered At :"+new Date().toString());
		context=new FileSystemXmlApplicationContext("file:C:/integrationservicesworkspace/IntegrationServices/configurations/wercsDatabase.xml");
		new WercsRegStatusRetryProcessor().processWercsRegStatusRetry();
	}

	@Override
	protected StepTransmitterBean jobLaunch(StepTransmitterBean transmitter) {

		return null;
	}

	public static void main(String[] args){
		
		ApplicationContext contextmaain = new FileSystemXmlApplicationContext("file:C:/integrationservicesworkspace/IntegrationServices/configurations/job-Scheduler-WercsRetry.xml");
	}
}
