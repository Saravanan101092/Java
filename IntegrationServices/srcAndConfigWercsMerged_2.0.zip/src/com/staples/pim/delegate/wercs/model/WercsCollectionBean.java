package com.staples.pim.delegate.wercs.model;

import java.util.HashMap;
import java.util.Map;


public class WercsCollectionBean {

	Map<String,String> attributeValueMap;
	
	public Map<String,String> getAttributeValueMap(){
		return attributeValueMap;
	}
	
	public void setAttributeValueMap(Map<String,String> map){
		attributeValueMap = map;
	}

	String PIPID=null;
	
	public String getPIPID() {
		
		return PIPID;
		
	}

	public void setPIPID(String wholeList) {
	
		PIPID = wholeList;
	}
}
