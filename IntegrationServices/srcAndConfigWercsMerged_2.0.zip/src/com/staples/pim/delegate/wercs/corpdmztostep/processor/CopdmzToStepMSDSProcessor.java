package com.staples.pim.delegate.wercs.corpdmztostep.processor;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class CopdmzToStepMSDSProcessor {

	public static void MSDSCopdmzToStepMSDSProcessor(File input) throws SQLException {
		
	     }  
}
